# Ghost Analytics Scripts

Scripts for managing analytics data in the Docker development environment.

## Docker Analytics Manager

Generates and clears analytics events directly in the local Tinybird instance.

**Prerequisites:**

- Docker environment running: `pnpm dev:analytics`
- Ghost database populated: `pnpm reset:data`

**Usage:**

```bash
# Generate analytics events (default: 10,000)
pnpm data:analytics:generate

# Generate custom number of events
pnpm data:analytics:generate 5000

# Clear all analytics data
pnpm data:analytics:clear
```

## Typical Workflow

```bash
# 1. Start the Docker environment with analytics
pnpm dev:analytics

# 2. (Optional) Reset Ghost data if needed
pnpm docker:reset:data

# 3. Generate analytics data
pnpm data:analytics:generate

# 4. View analytics in Ghost admin
# http://localhost:2368/ghost/#/stats

# 5. Clear analytics when needed
pnpm data:analytics:clear
```

**Note:** Use `pnpm docker:reset:data` when the Docker environment is running.
Use `pnpm reset:data` when running Ghost locally without Docker.

## Configuration

### Database Connection

Connects to MySQL at `localhost:3306`. Override via environment variables:

- `MYSQL_HOST` (default: localhost)
- `MYSQL_PORT` (default: 3306)
- `MYSQL_USER` (default: root)
- `MYSQL_PASSWORD` (default: root)
- `MYSQL_DATABASE` (default: ghost_dev)

### Tinybird Connection

The analytics Compose configuration mounts `docker/tinybird-local/query-memory.xml`
to set the local ClickHouse per-query memory limit to 4 GiB (the image defaults to
2 GB). This supports larger synthetic datasets; Docker must have enough memory
for concurrent queries and the other development services. Keep this limit the
same when comparing benchmark runs. This setting does not affect Tinybird Cloud.

Reads tokens from Docker volume automatically. Override via:

- `TINYBIRD_ADMIN_TOKEN`
- `TINYBIRD_TRACKER_TOKEN`
- `TINYBIRD_HOST` (default: http://localhost:7181)

## Troubleshooting

**"Could not retrieve Tinybird token"** - Ensure analytics is running: `pnpm dev:analytics`

**"Database connection failed"** - Check MySQL is running: `docker ps | grep mysql`

**No posts/members found** - Generate Ghost data first: `pnpm reset:data`

## Traffic endpoint performance baseline

With `pnpm dev:analytics` running and synthetic events loaded:

```bash
pnpm data:analytics:benchmark --output /tmp/traffic-baseline --iterations 5

# After deploying an improvement locally, replay exactly the same request parameters:
pnpm data:analytics:benchmark --manifest /tmp/traffic-baseline/manifest.json \
  --output /tmp/traffic-candidate --iterations 5
```

Each output directory must be new. The benchmark only connects to
`http://localhost:7181`, reads the local admin token from the Docker shared-config
volume, and never saves the token. It does not load, clear, or modify data.

The default manifest covers the 13 active, unsuffixed traffic endpoints. It runs
30-day and full-history cases for KPI and breakdown endpoints, plus post, source,
and audience KPI filters, lifetime post visitor counts and gift-link usage, and
live active visitors. It excludes automation, ingestion monitoring, and unused
versioned experiments. The date range ends on the dataset's latest day. The
post-count case requires at least one post UUID in the hit data.

The runner performs one warm-up per case followed by sequential measured rounds,
rotating case order between rounds. It saves:

- `manifest.json`: endpoint names and exact parameters; edit a copy to add cases
  or compare an experimental endpoint.
- `metadata.json`: dataset size, dimension coverage, runtime version, Git commit,
  and hashes of local Tinybird files. Deploy local file changes before measuring;
  these hashes do not prove that the running deployment matches the checkout.
- `samples.ndjson`: incremental raw HTTP measurements, response statistics,
  request IDs, result row counts, and result hashes.
- `results.json`: all samples enriched with matching `system.query_log` records,
  plus per-case summaries and missing-log diagnostics.
- `summary.md`: median total HTTP and engine duration, rows/bytes read, CPU time,
  peak query memory, and success/error counts.
- `explain/*.json`: expanded SQL and execution plans with partition/index/granule
  pruning, collected separately from timed requests.

HTTP time includes downloading the complete response body, but not JSON parsing.
CPU time sums the query's user and system thread time, so it can exceed elapsed
wall time when several cores work concurrently; it is not cluster CPU load.
Memory is peak query memory from ClickHouse. The runner waits for asynchronous
query-log delivery after timing ends, and leaves unavailable metrics null.
It applies a 35-second client deadline without retries and records failures.

Keep the same dataset, manifest, Docker CPU/memory allocation, and background
workload when comparing runs. These are warm-cache microbenchmarks, not cold-cache
or concurrency tests. No caches or logs are forcibly flushed. Five measurements
are a starting point; inspect individual samples and repeat before attributing
small timing differences to a code change. Result hashes ignore row ordering but
still need manual interpretation for top-N ties and time-dependent results.

The current generator does not populate gift links, known devices, UTM terms, or
UTM contents; active visitors may also be zero by the time measurements run.
Those cases measure empty-result paths, not realistic populated workloads.
`api_active_visitors` uses `now()`, so a saved manifest cannot freeze its window.
