no refs

## Summary

- Tinybird queries can run for 30 seconds, but Ghost previously abandoned requests after 10 seconds and inherited Got's automatic retries. Those retries could duplicate expensive work if Tinybird continued executing the original query, adding load during an incident.
- Raised Ghost's Tinybird request timeout to 35 seconds and disabled automatic retries. Added assertions to the existing request-options test. This change is limited to Ghost's server-side Tinybird client.

## Validation

- Tinybird client unit tests: 13 passed.
- Focused ESLint, formatting, dependency checks, and commit hooks passed.
- Full `pnpm check` stopped at a formatting issue in an existing, unrelated untracked `report.md`; that file is excluded from this PR.
