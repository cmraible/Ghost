# Local Tinybird performance workspace

This archive preserves the local benchmark scripts, source snapshots, measurements, reports, and sanitized logs alongside the KPI implementation. The original focused PR included only the KPI pipe, regression tests, and fixture data.

- `results/README.md`: original baseline, every experiment, rollout notes and checksummed raw artifacts. Files inside the archives are preserved unchanged. The former visualization location is a symlink here, so existing links continue to work.
- `benchmark-traffic.js`: runnable local benchmark, relocated from the Tinybird scripts folder.
- `workspace-before-cleanup.diff` and `workspace-files/`: original workspace-only changes, including benchmark documentation and package/Compose edits.
- `experiments/hourly/`: previous experimental materialization definitions. The installed local summary may remain but is unused by the current query.
- `query-memory.xml` and `compose.override.yaml`: local 4 GiB memory override; current running container already has this value. For future starts append `-f ai/traffic-analytics/compose.override.yaml` to the normal two-file Docker Compose invocation from the repo root.
- `logs/` and `original-temp-runs/`: preserved task logs and original temporary baseline copies.
- `report.md`: existing workspace report, preserved verbatim.

Run from the repository root:

```sh
pnpm exec node ai/traffic-analytics/benchmark-traffic.js --manifest ai/traffic-analytics/results/baseline-10m-4gib/manifest.json --output ai/traffic-analytics/results/candidate-next --iterations 5
```

Use a new output directory each time. Source snapshots and old metadata describe the historical checkout; their embedded paths/commands are intentionally unchanged. Baselines are measurements, not a backup of the 10-million-row Docker dataset. Preserve the existing Docker volumes.

## Pull request

Draft: https://github.com/TryGhost/Ghost/pull/30825

All 30 Tinybird test files passed, including 33 KPI cases. All 518 archived checksums were verified after relocation. Validation logs and the submitted PR description are retained here. Repository-wide formatting and linting passed; broader browser tests encountered local sandbox restrictions. See `logs/pnpm-check.log`.

The six Core files with timing failures passed on a single-worker retry (`logs/core-unit-retry.log`); all four Unsplash acceptance tests passed outside the sandbox (`logs/unsplash-acceptance-retry.log`). The larger Koenig browser suite was not rerun.

## Raw analytics export excluded

The 8 GB raw analytics export and all compressed copies are intentionally omitted
from this branch. Historical benchmark measurements, source snapshots, experiment
definitions, manifests, and query result samples remain available. The optional
`backup-local-tinybird.py` helper requires a separately supplied dataset; this
archive does not contain the raw-data backup needed by its restore command.

## Restart after testing other PRs

Start this worktree with both local overrides:

```sh
DEV_COMPOSE_FILES='-f compose.dev.analytics.yaml -f ai/traffic-analytics/compose.override.yaml' pnpm dev
```

The override keeps the 4 GiB query limit and points Ghost's analytics reads at the snapshot's original site UUID (`13d5f0ab-ce4f-47d1-b0e1-13f91f042f4d`). The current Ghost database has a different site UUID after other local testing. This preserves the benchmark events unchanged; newly tracked traffic uses the current site's identity. Post metadata in the current Ghost database may differ from the original dataset.

When restoring, Tinybird's initial build may insert fixture data, and cascading truncation of the raw automation-step source may leave the second-level `_mv_pending_automation_runs` table populated. Clear that derived table too before using the guarded restore helper. The 2026-09-16 reload log is in `logs/data-restore.log`.

Reload completed successfully in 100,000-row batches; see `logs/data-restore-batched.log`. All 10,000,000 analytics rows and all automation source rows matched their saved content fingerprints. All five KPI result hashes matched the original baseline; see `logs/restored-kpi-validation.json`. Ghost and analytics ingestion were then restarted with the local overrides.
