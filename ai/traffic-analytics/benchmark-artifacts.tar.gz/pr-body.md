no refs

## Summary

- `api_kpis` currently scans the same hits separately to identify eligible sessions and calculate their metrics. Combining these operations reduces repeated reads and joins for requests with both date bounds, including Admin's default `member_status=undefined,free,paid` filter.
- Qualification happens after session aggregation: every in-range hit still contributes to session metrics, combined hit filters must match the same hit, and source/device/UTM attribution still uses the first in-range hit. Requests with missing date bounds retain the existing query because its date defaults differ. The separate post/path/gift pageview calculation is preserved.
- Added 10 regression cases for changing audience status, paid/gift/comped audiences, empty statuses, combined filters, first-hit attribution and date boundaries.

## Performance

Local synthetic dataset of 10 million raw events, 4 GiB query memory limit, one warm-up and five measured rounds per case, concurrency 1. These are median measurements from the experiment, not production concurrency estimates.

| KPI case | HTTP duration | CPU time | Peak query memory |
| --- | ---: | ---: | ---: |
| 30 days, default audience filter | 370 → 203 ms | 906 → 569 ms | 661 → 213 MiB |
| 30 days, source filter | 411 → 119 ms | 1,324 → 551 ms | 726 → 276 MiB |
| Full history, unfiltered | 4,154 → 917 ms | 23,587 → 3,514 ms | 2,962 → 1,187 MiB |
| 30 days, post filter | 265 → 275 ms | 1,339 → 1,489 ms | 337 → 309 MiB |

The default-audience case reads roughly half as many rows; the source-filtered case reads roughly one third. The post-filtered case retains its separate pageview work and showed no latency improvement. All 156 requests across the 26-case benchmark succeeded and matched baseline result hashes.

## Validation

- All 30 Tinybird test files passed locally, including all 33 KPI cases.
- All 23 existing KPI snapshots are unchanged; the 10 new snapshots match independently calculated expectations.
- Benchmark scripts, results and experimental resources are preserved locally under gitignored `ai/traffic-analytics/`.
- Repository-wide formatting and linting passed. `pnpm check` did not fully pass: the Koenig browser suites encountered local sandbox launch restrictions, and six Core test files had timing failures during the full parallel run. All six Core files passed when rerun with one worker; all four Unsplash acceptance tests passed outside the sandbox. The larger Koenig browser suite was not rerun.
