const fs = require('node:fs');
const path = require('node:path');
const {execFileSync} = require('node:child_process');
const {createHash} = require('node:crypto');
(async () => {
  const baseline = JSON.parse(fs.readFileSync(path.join(__dirname, 'results/baseline-10m-4gib/results.json')));
  const config = execFileSync('docker', ['run', '--rm', '-v', 'ghost-dev_shared-config:/config:ro', 'alpine', 'cat', '/config/.env.tinybird'], {encoding:'utf8'});
  const token = config.match(/^TINYBIRD_ADMIN_TOKEN=(.+)$/m)[1].trim();
  const results = [];
  for (const entry of baseline.manifest.cases.filter(c => c.endpoint === 'api_kpis')) {
    const url = new URL('/v0/pipes/api_kpis.json', 'http://localhost:7181');
    for (const [key, value] of Object.entries(entry.params)) url.searchParams.set(key, value);
    const response = await fetch(url, {headers:{Authorization:`Bearer ${token}`},signal:AbortSignal.timeout(35000)});
    const body = await response.json();
    if (!response.ok || !Array.isArray(body.data)) throw new Error(`${entry.name}: HTTP ${response.status}`);
    const hash = createHash('sha256').update(JSON.stringify(body.data.map(row => JSON.stringify(row)).sort())).digest('hex');
    const expected = baseline.summary.find(s => s.case === entry.name).resultHashes;
    const result = {case:entry.name, status:response.status, rows:body.data.length, resultHash:hash, matchesBaseline:expected.includes(hash)};
    results.push(result);
    console.log(JSON.stringify(result));
  }
  fs.writeFileSync(path.join(__dirname,'logs/restored-kpi-validation.json'), JSON.stringify(results,null,2)+'\n');
  if (results.some(r => !r.matchesBaseline)) throw new Error('Restored KPI results differ from baseline');
})().catch(e => {console.error(e.message); process.exitCode=1;});
