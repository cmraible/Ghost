#!/usr/bin/env python3
"""Local-only raw Tinybird backup and guarded restore. Uses Python stdlib + Docker."""
import argparse
import datetime
import hashlib
import itertools
import json
from pathlib import Path
import re
import subprocess
import urllib.request

CONTAINER = 'ghost-dev-tinybird'
SOURCES = ['analytics_events', 'analytics_events_test', 'automation_run_events', 'automation_run_step_events']

def run(args, **kwargs):
    return subprocess.check_output(args, **kwargs)

def ch(query):
    return run(['docker', 'exec', CONTAINER, 'clickhouse-client', '--query', query], text=True)

def quote(value):
    return "'" + value.replace('\\', '\\\\').replace("'", "\\'") + "'"

def ident(value):
    return '`' + value.replace('`', '\\`') + '`'

def datasets():
    config = run(['docker', 'run', '--rm', '-v', 'ghost-dev_shared-config:/config:ro', 'alpine', 'cat', '/config/.env.tinybird'], text=True)
    token = re.search(r'^TINYBIRD_ADMIN_TOKEN=(.+)$', config, re.M)[1].strip()
    request = urllib.request.Request('http://localhost:7181/v0/datasources', headers={'Authorization': 'Bearer ' + token})
    with urllib.request.urlopen(request, timeout=30) as response:
        return {d['name']: d for d in json.load(response)['datasources']}

def table_for(ds):
    # Resolve current workspace IDs, never reuse physical IDs from an old backup.
    rows = [json.loads(line) for line in ch('SELECT database, name FROM system.tables WHERE startsWith(name, ' + quote(ds['id'] + '_v') + ") AND engine LIKE '%MergeTree' FORMAT JSONEachRow").splitlines()]
    if len(rows) != 1:
        raise RuntimeError(f"Expected one physical table for {ds['name']}, found {len(rows)}")
    return ident(rows[0]['database']) + '.' + ident(rows[0]['name'])

def columns(table):
    return [json.loads(line) for line in ch('DESCRIBE TABLE ' + table + ' FORMAT JSONEachRow').splitlines()]

def fingerprint_sql(cols):
    names = ', '.join(ident(c['name']) for c in cols)
    return 'SELECT count() AS rows, groupBitXor(cityHash64(tuple(' + names + '))) AS row_hash'

def file_digest(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        while chunk := stream.read(8 * 1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()

def check_file(folder, entry):
    path = folder / entry['file']
    assert file_digest(path) == entry['sha256'], f'Checksum mismatch: {path}'
    structure = ', '.join(ident(c['name']) + ' ' + c['type'] for c in entry['columns'])
    with path.open('rb') as stream:
        result = run(['docker', 'exec', '-i', CONTAINER, 'clickhouse-local', '--structure', structure, '--input-format', 'JSONEachRow', '--query', fingerprint_sql(entry['columns']) + ' FROM table FORMAT JSONEachRow'], stdin=stream, text=True)
    assert json.loads(result) == entry['fingerprint'], f'Row count/content mismatch: {path}'
    print(f"Verified {entry['name']}: {entry['fingerprint']['rows']} rows", flush=True)

def backup(folder):
    folder.mkdir(parents=True, exist_ok=False)
    ds = datasets()
    manifest = {'created_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'format': 'ClickHouse JSONEachRow (NDJSON), raw column values', 'container': CONTAINER, 'datasets': [], 'workspace_datasources': [{'name': d['name'], 'statistics': d.get('statistics')} for d in ds.values()]}
    for name in SOURCES:
        if name not in ds:
            continue
        table = table_for(ds[name])
        cols = columns(table)
        fingerprint = json.loads(ch(fingerprint_sql(cols) + ' FROM ' + table + ' FORMAT JSONEachRow'))
        entry = {'name': name, 'file': name + '.ndjson', 'columns': cols, 'fingerprint': fingerprint, 'source_table': table}
        partial = folder / (entry['file'] + '.partial')
        print(f"Exporting {name}: {fingerprint['rows']} rows", flush=True)
        with partial.open('xb') as stream:
            subprocess.run(['docker', 'exec', CONTAINER, 'clickhouse-client', '--query', 'SELECT ' + ', '.join(ident(c['name']) for c in cols) + ' FROM ' + table + ' FORMAT JSONEachRow'], stdout=stream, check=True)
        entry['bytes'] = partial.stat().st_size
        entry['sha256'] = file_digest(partial)
        partial.rename(folder / entry['file'])
        check_file(folder, entry)
        after = json.loads(ch(fingerprint_sql(cols) + ' FROM ' + table + ' FORMAT JSONEachRow'))
        assert after == fingerprint, 'Source changed during export; retry when ingestion is idle'
        manifest['datasets'].append(entry)
        (folder / 'manifest.in-progress.json').write_text(json.dumps(manifest, indent=2) + '\n')
    (folder / 'manifest.in-progress.json').rename(folder / 'manifest.json')
    print('Backup complete: ' + str(folder), flush=True)

def restore(folder, verify_only):
    manifest = json.loads((folder / 'manifest.json').read_text())
    for entry in manifest['datasets']:
        check_file(folder, entry)
    if verify_only:
        return
    ds = datasets()
    # Refuse to mix snapshots or double-count existing materialized aggregates.
    for name, source in ds.items():
        table = table_for(source)
        count = int(ch('SELECT count() FROM ' + table))
        if count:
            raise RuntimeError(f'Restore requires a fresh, empty workspace: {name} has {count} rows. No data was imported.')
    targets = {}
    entries = [e for e in manifest['datasets'] if int(e['fingerprint']['rows']) or e['name'] in ds]
    for entry in entries:
        table = table_for(ds[entry['name']])
        expected = [(c['name'], c['type']) for c in entry['columns']]
        actual = [(c['name'], c['type']) for c in columns(table)]
        if actual != expected:
            raise RuntimeError(f"Schema mismatch for {entry['name']}; no data was imported")
        targets[entry['name']] = table
    for entry in entries:
        table = targets[entry['name']]
        if int(entry['fingerprint']['rows']):
            print('Restoring ' + entry['name'], flush=True)
            inserted = 0
            with (folder / entry['file']).open('rb') as stream:
                while rows := list(itertools.islice(stream, 100000)):
                    # Independent bounded inserts release aggregation state between batches.
                    # Never retry an uncertain batch automatically: inserts are not idempotent.
                    subprocess.run(['docker', 'exec', '-i', CONTAINER, 'clickhouse-client',
                                    '--max_insert_block_size', '100000', '--max_insert_threads', '1',
                                    '--max_threads', '2', '--input_format_parallel_parsing', '0',
                                    '--query', 'INSERT INTO ' + table + ' (' + ', '.join(ident(c['name']) for c in entry['columns']) + ') FORMAT JSONEachRow'], input=b''.join(rows), check=True)
                    inserted += len(rows)
                    if inserted % 1000000 == 0 or inserted == int(entry['fingerprint']['rows']):
                        print(f"Inserted {inserted} / {entry['fingerprint']['rows']} {entry['name']} rows", flush=True)
        actual = json.loads(ch(fingerprint_sql(entry['columns']) + ' FROM ' + table + ' FORMAT JSONEachRow'))
        assert actual == entry['fingerprint'], f"Restored data mismatch for {entry['name']}"
        print('Restored and verified ' + entry['name'], flush=True)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['export', 'verify', 'restore'])
    parser.add_argument('directory', type=Path)
    args = parser.parse_args()
    if args.action == 'export':
        backup(args.directory.resolve())
    else:
        restore(args.directory.resolve(), args.action == 'verify')
