#!/usr/bin/env node
/* eslint-disable no-console, ghost/ghost-custom/no-native-error */
// Local-only, sequential endpoint benchmark. Never logs authentication material.
const { execFileSync } = require('node:child_process');
const { createHash } = require('node:crypto');
const fs = require('node:fs/promises');
const path = require('node:path');
const { parseArgs } = require('node:util');
const root = execFileSync('git', ['rev-parse', '--show-toplevel'], { cwd: __dirname, encoding: 'utf8' }).trim();
const tinybirdRoot = path.join(root, 'ghost/core/core/server/data/tinybird');
const Database = require(path.join(tinybirdRoot, 'scripts/docker-database-utils'));

const { values } = parseArgs({
  options: {
    output: { type: 'string' },
    manifest: { type: 'string' },
    iterations: { type: 'string', default: '5' },
    help: { type: 'boolean' },
  },
});
const host = 'http://localhost:7181';
const sleep = (ms) =>
  new Promise((resolve) => {
    setTimeout(resolve, ms);
  });
const quote = (value) => "'" + value.replaceAll("'", "''") + "'";
const median = (numbers) => {
  const sorted = numbers.filter((v) => v !== null && v !== undefined).sort((a, b) => a - b);
  const middle = Math.floor(sorted.length / 2);
  return sorted.length
    ? sorted.length % 2
      ? sorted[middle]
      : (sorted[middle - 1] + sorted[middle]) / 2
    : null;
};

async function main() {
  if (values.help) {
    console.log(
      'pnpm exec node ai/traffic-analytics/benchmark-traffic.js [--output /tmp/baseline] [--iterations 5] [--manifest /tmp/baseline/manifest.json]',
    );
    return;
  }
  const iterations = Number(values.iterations);
  if (!Number.isInteger(iterations) || iterations < 1 || iterations > 100) {
    throw new Error('iterations must be an integer from 1 to 100');
  }
  const output = path.resolve(values.output || `/tmp/ghost-traffic-benchmark-${Date.now()}`);
  // Refuse to overwrite a previous baseline.
  await fs.mkdir(output);
  const config = execFileSync(
    'docker',
    [
      'run',
      '--rm',
      '-v',
      'ghost-dev_shared-config:/config:ro',
      'alpine',
      'cat',
      '/config/.env.tinybird',
    ],
    { encoding: 'utf8' },
  );
  const token = config.match(/^TINYBIRD_ADMIN_TOKEN=(.+)$/m)?.[1].trim();
  if (!token) {
    throw new Error('No local Tinybird token; run pnpm dev:analytics first');
  }
  const headers = { Authorization: `Bearer ${token}` };
  async function request(route, params) {
    const url = new URL(route, host);
    Object.entries(params).forEach(([key, value]) => url.searchParams.set(key, value));
    const started = performance.now();
    const response = await fetch(url, {
      headers,
      signal: AbortSignal.timeout(35000),
      redirect: 'error',
    });
    const text = await response.text();
    const httpMs = performance.now() - started;
    let body;
    try {
      body = JSON.parse(text);
    } catch {
      body = { error: text };
    }
    return {
      status: response.status,
      requestId: response.headers.get('x-request-id'),
      httpMs,
      body,
    };
  }
  async function sql(query) {
    const result = await request('/v0/sql', { q: query + ' FORMAT JSON' });
    if (result.status !== 200 || !Array.isArray(result.body.data)) {
      throw new Error(result.body.error || `SQL failed: HTTP ${result.status}`);
    }
    return result.body.data;
  }
  let manifest;
  if (values.manifest) {
    manifest = JSON.parse(await fs.readFile(values.manifest, 'utf8'));
  } else {
    const db = new Database();
    let site;
    try {
      site = await db.getSiteUuid();
    } finally {
      await db.close();
    }
    const [extent] = await sql(
      `SELECT toDate(min(timestamp)) AS first, toDate(max(timestamp)) AS last FROM _mv_hits WHERE site_uuid=${quote(site)}`,
    );
    const posts = await sql(
      `SELECT post_uuid, count() AS hits FROM _mv_hits WHERE site_uuid=${quote(site)} AND post_uuid NOT IN ('', 'undefined') GROUP BY post_uuid ORDER BY hits DESC, post_uuid LIMIT 20`,
    );
    const last = new Date(extent.last + 'T00:00:00Z');
    const from = new Date(last.getTime() - 29 * 86400000).toISOString().slice(0, 10);
    const base = { site_uuid: site, timezone: 'Etc/UTC', date_from: from, date_to: extent.last };
    const endpoints = [
      'api_kpis',
      'api_top_pages',
      'api_top_sources',
      'api_top_locations',
      'api_top_devices',
      'api_top_utm_sources',
      'api_top_utm_mediums',
      'api_top_utm_campaigns',
      'api_top_utm_terms',
      'api_top_utm_contents',
    ];
    const cases = [];
    for (const endpoint of endpoints) {
      cases.push({ name: endpoint + '-30d', endpoint, params: base });
      cases.push({
        name: endpoint + '-history',
        endpoint,
        params: { ...base, date_from: extent.first },
      });
    }
    if (posts.length) {
      cases.push({
        name: 'api_kpis-post-30d',
        endpoint: 'api_kpis',
        params: { ...base, post_uuid: posts[0].post_uuid },
      });
      cases.push({
        name: 'api_post_visitor_counts-lifetime',
        endpoint: 'api_post_visitor_counts',
        params: { site_uuid: site, post_uuids: posts.map((p) => p.post_uuid).join(',') },
      });
    }
    cases.push({
      name: 'api_kpis-source-30d',
      endpoint: 'api_kpis',
      params: { ...base, source: 'Google' },
    });
    cases.push({
      name: 'api_kpis-audience-30d',
      endpoint: 'api_kpis',
      params: { ...base, member_status: 'undefined,free,paid' },
    });
    cases.push({
      name: 'api_active_visitors-live',
      endpoint: 'api_active_visitors',
      params: { site_uuid: site },
    });
    cases.push({
      name: 'api_gift_link_visits-lifetime',
      endpoint: 'api_gift_link_visits',
      params: { site_uuid: site },
    });
    manifest = { version: 1, site, cases };
  }
  if (
    !manifest.site ||
    !manifest.cases?.length ||
    manifest.cases.some(
      (c) =>
        !/^[a-z0-9_]+$/.test(c.endpoint) ||
        !/^[a-z0-9_-]+$/.test(c.name) ||
        c.params.site_uuid !== manifest.site,
    )
  ) {
    throw new Error('Invalid benchmark manifest');
  }
  await fs.writeFile(path.join(output, 'manifest.json'), JSON.stringify(manifest, null, 2));
  const dataset = await sql(
    `SELECT count() AS hits, uniqExact(session_id) AS sessions, min(timestamp) AS first_hit, max(timestamp) AS last_hit, countIf(gift_link != '') AS gift_hits, countIf(device != 'unknown') AS known_device_hits, countIf(utm_term != '') AS utm_term_hits, countIf(utm_content != '') AS utm_content_hits, countIf(timestamp >= now()-INTERVAL 5 MINUTE) AS live_hits FROM _mv_hits WHERE site_uuid=${quote(manifest.site)}`,
  );
  const sourceHashes = {};
  for (const folder of ['endpoints', 'pipes', 'datasources']) {
    for (const file of (await fs.readdir(path.join(tinybirdRoot, folder))).sort()) {
      if (!/\.(pipe|datasource)$/.test(file)) {
        continue;
      }
      sourceHashes[`${folder}/${file}`] = createHash('sha256')
        .update(await fs.readFile(path.join(tinybirdRoot, folder, file)))
        .digest('hex');
    }
  }
  const metadata = {
    startedAt: new Date().toISOString(),
    host,
    iterations,
    warmups: 1,
    concurrency: 1,
    node: process.version,
    gitCommit: execFileSync('git', ['rev-parse', 'HEAD'], { cwd: root, encoding: 'utf8' }).trim(),
    dataset,
    sourceHashes,
    notes: [
      'Warm-cache sequential microbenchmark, not a concurrency/load test.',
      'Live visitor window moves with wall clock.',
      'Source hashes describe checkout files; deploy edits locally before comparing.',
      'HTTP duration includes full response body download, excludes JSON parsing.',
      'No cache flush, server restart, or query-log flush is performed.',
    ],
  };
  await fs.writeFile(path.join(output, 'metadata.json'), JSON.stringify(metadata, null, 2));
  await fs.mkdir(path.join(output, 'explain'));
  const samples = [];
  async function measure(testCase, iteration) {
    try {
      const r = await request(`/v0/pipes/${testCase.endpoint}.json`, testCase.params);
      const sample = {
        case: testCase.name,
        iteration,
        status: r.status,
        requestId: r.requestId,
        httpMs: r.httpMs,
        statistics: r.body.statistics || null,
        resultRows: r.body.data?.length ?? null,
        resultHash: r.body.data
          ? createHash('sha256')
              .update(JSON.stringify(r.body.data.map((row) => JSON.stringify(row)).sort()))
              .digest('hex')
          : null,
        error: r.body.error || null,
      };
      samples.push(sample);
      await fs.appendFile(path.join(output, 'samples.ndjson'), JSON.stringify(sample) + '\n');
    } catch (error) {
      const sample = {
        case: testCase.name,
        iteration,
        status: null,
        requestId: null,
        error: error.message,
      };
      samples.push(sample);
      await fs.appendFile(path.join(output, 'samples.ndjson'), JSON.stringify(sample) + '\n');
    }
  }
  // One warm-up per case; rotate the starting case each round to reduce ordering bias.
  for (let iteration = 0; iteration <= iterations; iteration++) {
    for (let offset = 0; offset < manifest.cases.length; offset++) {
      await measure(manifest.cases[(offset + iteration) % manifest.cases.length], iteration);
    }
    console.log(`Completed ${iteration === 0 ? 'warm-up' : `round ${iteration}/${iterations}`}`);
  }
  // Explain requests run separately and are excluded from measured samples.
  for (const testCase of manifest.cases) {
    try {
      const result = await request(`/v0/pipes/${testCase.endpoint}.json`, {
        ...testCase.params,
        explain: 'true',
      });
      await fs.writeFile(
        path.join(output, 'explain', testCase.name + '.json'),
        JSON.stringify(result, null, 2),
      );
    } catch (error) {
      await fs.writeFile(
        path.join(output, 'explain', testCase.name + '.json'),
        JSON.stringify({ error: error.message }),
      );
    }
  }
  const ids = samples.map((s) => s.requestId).filter(Boolean);
  let logs = [];
  let logError = null;
  // ClickHouse writes query logs asynchronously. Poll after measurements so log reads
  // do not compete with timed queries. Missing metrics remain null, never zero.
  if (ids.length) {
    for (let attempt = 0; attempt < 16; attempt++) {
      try {
        logs = await sql(
          `SELECT query_id, query_duration_ms, read_rows, read_bytes, memory_usage, result_rows, peak_threads_usage, query_cache_usage, ProfileEvents['UserTimeMicroseconds'] AS cpu_user_us, ProfileEvents['SystemTimeMicroseconds'] AS cpu_system_us, mapContains(ProfileEvents,'UserTimeMicroseconds') AS has_cpu, ProfileEvents['SelectedMarks'] AS selected_marks, ProfileEvents['SelectedParts'] AS selected_parts FROM system.query_log WHERE event_time >= now()-INTERVAL 1 HOUR AND type='QueryFinish' AND is_initial_query=1 AND query_id IN (${ids.map(quote).join(',')})`,
        );
        if (new Set(logs.map((l) => l.query_id)).size === ids.length) {
          break;
        }
      } catch (error) {
        logError = error.message;
        break;
      }
      await sleep(2000);
    }
  }
  const byId = new Map(logs.map((log) => [log.query_id, log]));
  for (const sample of samples) {
    sample.queryLog = byId.get(sample.requestId) || null;
  }
  const summary = manifest.cases.map((testCase) => {
    const measured = samples.filter((s) => s.case === testCase.name && s.iteration > 0);
    const ok = measured.filter((s) => s.status === 200 && !s.error);
    const cpu = (s) =>
      s.queryLog?.has_cpu
        ? (Number(s.queryLog.cpu_user_us) + Number(s.queryLog.cpu_system_us)) / 1000
        : null;
    return {
      case: testCase.name,
      successes: ok.length,
      failures: measured.length - ok.length,
      logSamples: ok.filter((s) => s.queryLog).length,
      httpMedianMs: median(ok.map((s) => s.httpMs)),
      httpMinMs: ok.length ? Math.min(...ok.map((s) => s.httpMs)) : null,
      httpMaxMs: ok.length ? Math.max(...ok.map((s) => s.httpMs)) : null,
      engineMedianMs: median(
        ok.map((s) => (s.statistics?.elapsed === undefined ? null : s.statistics.elapsed * 1000)),
      ),
      rowsReadMedian: median(ok.map((s) => s.statistics?.rows_read)),
      bytesReadMedian: median(ok.map((s) => s.statistics?.bytes_read)),
      cpuMedianMs: median(ok.map(cpu)),
      peakMemoryMedianBytes: median(
        ok.map((s) => (!s.queryLog ? null : Number(s.queryLog.memory_usage))),
      ),
      resultRowsMedian: median(ok.map((s) => s.resultRows)),
      resultHashes: [...new Set(ok.map((s) => s.resultHash))],
    };
  });
  const result = { metadata, manifest, logError, summary, samples };
  await fs.writeFile(path.join(output, 'results.json'), JSON.stringify(result, null, 2));
  const number = (n, divisor = 1) => (n === null ? 'n/a' : (n / divisor).toFixed(2));
  const lines = [
    '# Traffic analytics baseline',
    '',
    `Measured ${iterations} sequential requests per case after one warm-up. CPU is summed user + system thread time; memory is query-log peak memory.`,
    '',
    '| Case | HTTP median ms | Engine ms | Rows read | Read MiB | CPU ms | Peak MiB | OK / errors |',
    '|---|---:|---:|---:|---:|---:|---:|---:|',
  ];
  for (const s of summary) {
    lines.push(
      `| ${s.case} | ${number(s.httpMedianMs)} | ${number(s.engineMedianMs)} | ${s.rowsReadMedian ?? 'n/a'} | ${number(s.bytesReadMedian, 1048576)} | ${number(s.cpuMedianMs)} | ${number(s.peakMemoryMedianBytes, 1048576)} | ${s.successes} / ${s.failures} |`,
    );
  }
  lines.push(
    '',
    'See metadata.json for dataset coverage and source hashes; results.json for individual requests, ranges, result hashes, and missing query-log metrics. Explain files contain expanded SQL and index/granule pruning.',
    '',
    'Known coverage gaps are recorded in metadata.dataset. Empty-result queries are not representative of populated dimensions. Live visitor requests cannot be replayed at a frozen time.',
  );
  await fs.writeFile(path.join(output, 'summary.md'), lines.join('\n') + '\n');
  console.log(`Saved ${samples.length} samples and ${logs.length} query logs to ${output}`);
  if (summary.some((s) => s.failures)) {
    process.exitCode = 1;
  }
}
main().catch((error) => {
  console.error(error.message);
  process.exitCode = 1;
});
