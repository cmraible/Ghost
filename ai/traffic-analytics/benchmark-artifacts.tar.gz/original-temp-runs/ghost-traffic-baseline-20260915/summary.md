# Traffic analytics baseline

Measured 5 sequential requests per case after one warm-up. CPU is summed user + system thread time; memory is query-log peak memory.

| Case | HTTP median ms | Engine ms | Rows read | Read MiB | CPU ms | Peak MiB | OK / errors |
|---|---:|---:|---:|---:|---:|---:|---:|
| api_kpis-30d | 45.13 | 35.48 | 419070 | 19.58 | 68.77 | 64.58 | 5 / 0 |
| api_kpis-history | 128.67 | 114.21 | 2000002 | 93.46 | 351.04 | 289.14 | 5 / 0 |
| api_top_pages-30d | 45.15 | 35.59 | 1209534 | 125.29 | 122.68 | 78.69 | 5 / 0 |
| api_top_pages-history | 91.77 | 82.31 | 2000000 | 162.23 | 364.88 | 270.93 | 5 / 0 |
| api_top_sources-30d | 37.73 | 28.98 | 419068 | 21.53 | 61.84 | 61.39 | 5 / 0 |
| api_top_sources-history | 94.51 | 86.02 | 2000000 | 102.74 | 389.46 | 319.95 | 5 / 0 |
| api_top_locations-30d | 35.83 | 27.30 | 1209534 | 62.70 | 79.00 | 50.64 | 5 / 0 |
| api_top_locations-history | 81.20 | 71.72 | 2000000 | 99.64 | 254.74 | 283.79 | 5 / 0 |
| api_top_devices-30d | 36.64 | 26.51 | 419068 | 22.58 | 61.93 | 61.90 | 5 / 0 |
| api_top_devices-history | 93.33 | 81.41 | 2000000 | 107.77 | 365.72 | 316.39 | 5 / 0 |
| api_top_utm_sources-30d | 40.56 | 30.18 | 419068 | 21.42 | 69.58 | 63.65 | 5 / 0 |
| api_top_utm_sources-history | 88.88 | 79.96 | 2000000 | 102.24 | 353.96 | 311.79 | 5 / 0 |
| api_top_utm_mediums-30d | 37.31 | 26.65 | 419068 | 21.36 | 62.01 | 58.01 | 5 / 0 |
| api_top_utm_mediums-history | 90.95 | 81.21 | 2000000 | 101.93 | 339.29 | 309.57 | 5 / 0 |
| api_top_utm_campaigns-30d | 45.99 | 37.13 | 419068 | 21.61 | 86.38 | 127.39 | 5 / 0 |
| api_top_utm_campaigns-history | 98.00 | 86.61 | 2000000 | 103.12 | 347.75 | 307.41 | 5 / 0 |
| api_top_utm_terms-30d | 37.45 | 28.66 | 419068 | 21.18 | 55.02 | 58.56 | 5 / 0 |
| api_top_utm_terms-history | 87.88 | 78.33 | 2000000 | 101.09 | 295.11 | 298.07 | 5 / 0 |
| api_top_utm_contents-30d | 41.09 | 27.62 | 419068 | 21.18 | 54.20 | 61.76 | 5 / 0 |
| api_top_utm_contents-history | 90.58 | 81.24 | 2000000 | 101.09 | 299.09 | 305.81 | 5 / 0 |
| api_kpis-post-30d | 65.73 | 54.59 | 1628605 | 121.34 | 123.03 | 53.64 | 5 / 0 |
| api_post_visitor_counts-lifetime | 38.41 | 29.20 | 1000000 | 74.59 | 109.99 | 40.52 | 5 / 0 |
| api_kpis-source-30d | 65.37 | 54.54 | 628604 | 31.32 | 116.94 | 75.17 | 5 / 0 |
| api_kpis-audience-30d | 49.26 | 39.57 | 419071 | 22.80 | 71.06 | 57.92 | 5 / 0 |
| api_active_visitors-live | 10.74 | 2.43 | 0 | 0.00 | 3.22 | 4.04 | 5 / 0 |
| api_gift_link_visits-lifetime | 11.83 | 3.47 | 0 | 0.00 | 4.34 | 7.04 | 5 / 0 |

See metadata.json for dataset coverage and source hashes; results.json for individual requests, ranges, result hashes, and missing query-log metrics. Explain files contain expanded SQL and index/granule pruning.

Known coverage gaps are recorded in metadata.dataset. Empty-result queries are not representative of populated dimensions. Live visitor requests cannot be replayed at a frozen time.
