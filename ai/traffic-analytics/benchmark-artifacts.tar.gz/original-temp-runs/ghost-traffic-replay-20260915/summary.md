# Traffic analytics baseline

Measured 5 sequential requests per case after one warm-up. CPU is summed user + system thread time; memory is query-log peak memory.

| Case | HTTP median ms | Engine ms | Rows read | Read MiB | CPU ms | Peak MiB | OK / errors |
|---|---:|---:|---:|---:|---:|---:|---:|
| api_kpis-30d | 50.09 | 40.00 | 419070 | 19.58 | 75.22 | 64.54 | 5 / 0 |
| api_kpis-history | 137.70 | 126.71 | 2000002 | 93.46 | 393.25 | 281.75 | 5 / 0 |
| api_top_pages-30d | 48.19 | 39.78 | 1209534 | 125.29 | 133.92 | 83.38 | 5 / 0 |
| api_top_pages-history | 94.31 | 83.95 | 2000000 | 162.23 | 393.68 | 271.42 | 5 / 0 |
| api_top_sources-30d | 44.15 | 33.16 | 419068 | 21.53 | 68.35 | 58.86 | 5 / 0 |
| api_top_sources-history | 101.51 | 92.28 | 2000000 | 102.74 | 390.41 | 328.11 | 5 / 0 |
| api_top_locations-30d | 36.78 | 27.68 | 1209534 | 62.70 | 90.33 | 75.76 | 5 / 0 |
| api_top_locations-history | 83.96 | 75.50 | 2000000 | 99.64 | 271.91 | 281.37 | 5 / 0 |
| api_top_devices-30d | 39.33 | 29.52 | 419068 | 22.58 | 63.39 | 63.71 | 5 / 0 |
| api_top_devices-history | 94.58 | 86.67 | 2000000 | 107.77 | 388.97 | 335.22 | 5 / 0 |
| api_top_utm_sources-30d | 39.45 | 30.33 | 419068 | 21.42 | 66.41 | 58.99 | 5 / 0 |
| api_top_utm_sources-history | 109.65 | 92.10 | 2000000 | 102.24 | 386.77 | 313.30 | 5 / 0 |
| api_top_utm_mediums-30d | 42.59 | 33.69 | 419068 | 21.36 | 72.18 | 69.80 | 5 / 0 |
| api_top_utm_mediums-history | 95.77 | 85.98 | 2000000 | 101.93 | 367.75 | 306.86 | 5 / 0 |
| api_top_utm_campaigns-30d | 43.97 | 35.28 | 419068 | 21.61 | 76.23 | 61.91 | 5 / 0 |
| api_top_utm_campaigns-history | 103.24 | 93.74 | 2000000 | 103.12 | 373.21 | 306.51 | 5 / 0 |
| api_top_utm_terms-30d | 36.27 | 26.91 | 419068 | 21.18 | 57.49 | 57.51 | 5 / 0 |
| api_top_utm_terms-history | 86.96 | 78.51 | 2000000 | 101.09 | 317.19 | 308.61 | 5 / 0 |
| api_top_utm_contents-30d | 36.60 | 27.31 | 419068 | 21.18 | 56.19 | 61.53 | 5 / 0 |
| api_top_utm_contents-history | 100.96 | 90.83 | 2000000 | 101.09 | 334.86 | 307.08 | 5 / 0 |
| api_kpis-post-30d | 64.77 | 54.90 | 1628605 | 121.34 | 123.75 | 54.02 | 5 / 0 |
| api_post_visitor_counts-lifetime | 39.55 | 30.50 | 1000000 | 74.59 | 126.89 | 53.54 | 5 / 0 |
| api_kpis-source-30d | 65.01 | 54.40 | 628604 | 31.32 | 121.56 | 71.54 | 5 / 0 |
| api_kpis-audience-30d | 51.00 | 41.28 | 419071 | 22.80 | 77.48 | 63.68 | 5 / 0 |
| api_active_visitors-live | 10.14 | 2.65 | 0 | 0.00 | 3.78 | 4.04 | 5 / 0 |
| api_gift_link_visits-lifetime | 10.94 | 3.63 | 0 | 0.00 | 4.79 | 7.04 | 5 / 0 |

See metadata.json for dataset coverage and source hashes; results.json for individual requests, ranges, result hashes, and missing query-log metrics. Explain files contain expanded SQL and index/granule pruning.

Known coverage gaps are recorded in metadata.dataset. Empty-result queries are not representative of populated dimensions. Live visitor requests cannot be replayed at a frozen time.
