## Conclusion

  Both incidents were triggered by overlapping year-to-date analytics queries for one large site: Hyperallergic on September 14 and Alison Roman on September 15. The
  active SQL performs substantial work over raw hits, and Ghost’s server-side retries very likely amplified the overlap.

  I saved the full investigation report (/tmp/tinybird-rca/report.md) and 36 query results with their SQL (/tmp/tinybird-rca/evidence-final.json). The repository is
  unchanged.

  ### The two incidents

  All times are UTC. These windows describe the load bursts, which started before Tinybird applied its restrictions.

                                                              September 14, 21:40–21:44    September 15, 13:17–13:18
  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  ━━━━━━━━━━━━━━━━━━━━━━━━━━━  ━━━━━━━━━━━━━━━━━━━━━━━━━━━
   Main contributing site                                             hyperallergic.com         www.alisoneroman.com
  ─────────────────────────────────────────────────────────  ───────────────────────────  ───────────────────────────
   Site’s share of logged read CPU                                                92.8%                        93.7%
  ─────────────────────────────────────────────────────────  ───────────────────────────  ───────────────────────────
   Year-to-date requests from that site                                              29                           13
  ─────────────────────────────────────────────────────────  ───────────────────────────  ───────────────────────────
   Approximate overlapping YTD requests on busiest replica                           11                            8
  ─────────────────────────────────────────────────────────  ───────────────────────────  ───────────────────────────
   Peak tracked server memory                                                 27.44 GiB                    22.67 GiB
  ─────────────────────────────────────────────────────────  ───────────────────────────  ───────────────────────────
   Largest individual query memory                                             4.24 GiB                     3.27 GiB
  ─────────────────────────────────────────────────────────  ───────────────────────────  ───────────────────────────
   Timed-out requests                                                                13                            4
  ─────────────────────────────────────────────────────────  ───────────────────────────  ───────────────────────────
   Subsequent rate-limit rejections                                   33 across 7 sites       4 across 4 other sites

  The site attribution comes from request parameters, cross-checked against hostnames in the sites’ recorded page hits.

  ## 1. Did a deployment cause this?

  There is no evidence of an incident-time Tinybird deployment.

  The latest recorded production deployment was September 10 at 14:03, four days before the first incident. Its datasource creations align with the automation analytics
  change (https://github.com/TryGhost/Ghost/commit/72730ac2fa523d04d9296d229a6b7fbd81d8b454). That change:

  - Added separate automation datasources and pipes.
  - Did not modify the four affected analytics endpoints or their shared session queries.
  - Produced no observed automation ingestion traffic in the inspected period.

  There were no recorded deployment jobs or datasource structural changes on September 14–15 before the investigation cutoff. Hardware metrics consistently reported two
  replicas, each with four CPUs and 30.84 GiB RAM.

  There is a separate performance change that remains unexplained: ordinary query CPU costs increased around September 10. For example, active-visitor queries rose from
  roughly 5.8–6.1 ms to about 7.1 ms CPU per request. That increase began around 11:00–12:00, before the 14:03 deployment.

  It may have reduced available headroom, but I cannot establish its cause or whether it was necessary for these incidents. Tinybird-internal changes and the exact Ghost/
  Admin versions running on these sites are not exposed by the inspected logs.

  ## 2. Did traffic patterns change?

  The meaningful change was much more work per request, with concentrated overlapping requests. Overall request volume stayed fairly normal.

   Metric                                       Before incident 1    Incident 1    Before incident 2    Incident 2
  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  ━━━━━━━━━━━━━━━━━━━  ━━━━━━━━━━━━  ━━━━━━━━━━━━━━━━━━━  ━━━━━━━━━━━━
   Requests/minute                                            395           413                  441           447
  ───────────────────────────────────────────  ───────────────────  ────────────  ───────────────────  ────────────
   Requests/minute excluding active visitors                   59            77                   92            95
  ───────────────────────────────────────────  ───────────────────  ────────────  ───────────────────  ────────────
   Read CPU seconds/minute                                   9.43        136.11                18.60        194.02

  The quiet controls are five-minute periods near each incident.

  Total request rates increased only 4.5% and 1.3%, while read CPU increased 14.4× and 10.4×. The first incident did have a meaningful increase in non-realtime requests,
  but neither was a workspace-wide traffic flood.

  ### What the expensive requests asked for

  Hyperallergic:

  - Switched from approximately 31-day analytics to January 1–September 14.
  - Repeatedly changed audience selection: free members → members → all audiences → anonymous visitors.
  - Issued batches across KPIs, top pages, sources, and locations, sometimes seconds apart.
  - Had no January-1-start requests in the preceding September 8–13 comparison period.

  Alison Roman:

  - Switched to January 1–September 15.
  - Issued several overlapping batches with broadly identical parameters.
  - Had no January-1-start requests during September 8–14.
  - Repeated the pattern at 13:27, causing another substantial resource spike, although that later burst completed without another limiter event.

  There were zero source/device/UTM-filter requests in either original burst window. Complex attribution filters were not the trigger. Long date ranges, large sites, broad
  audience selections, and concurrent execution were the relevant combination.

  ## 3. Why were these queries so expensive?

  The active endpoints perform repeated processing over raw hits.

  ### Session data is rebuilt during requests

  Despite its name, ghost/core/core/server/data/tinybird/pipes/mv_session_data.pipe:3 is a query-time aggregation, not the materialized session table. It groups raw hits
  by session and calculates pageviews, timestamps, source, device, and other attributes.

  Separately, filtered_sessions builds a distinct set of qualifying session IDs. The endpoints then join and aggregate these results.

  Each dashboard endpoint executes independently, repeating substantial work.

  ### Top pages and locations also scan outside the selected date range

  In api_top_pages (ghost/core/core/server/data/tinybird/endpoints/api_top_pages.pipe:8) and api_top_locations, the date range restricts the session-selection query. The
  outer hits scan has no timestamp restriction.

  I reconstructed the observed top-pages request and ran EXPLAIN only. Its plan confirms:

  - The session-selection scan uses timestamp and month filters.
  - The outer scan filters by site but has no date-based pruning.

  That explains why even Hyperallergic’s ordinary 31-day top-pages requests read roughly 12 million rows. Its heavy year-to-date requests read approximately 18–20 million
  rows; Alison Roman’s read approximately 12.6–16.5 million.

  The materialized _mv_session_data_v2 and _mv_daily_pages tables exist and receive writes, but the unsuffixed endpoints used during these incidents do not read them.

  ## 4. Retries likely amplified the load

  This is a particularly strong contributing-factor finding.

  Ghost’s server-side Tinybird client has a 10-second timeout, while some Tinybird requests continue for approximately 30 seconds. The production HTTP client inherits
  Got’s default two retries for GET timeouts. Ghost client configuration (ghost/core/core/server/lib/request-external.js:300), Got retry defaults
  (https://github.com/sindresorhus/got/blob/v16.0.0/source/core/options.ts#L1216).

  Identical top-pages requests from the Ghost user agent appeared at:

   Request                              Start times
  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
   Hyperallergic, YTD, all audiences    21:42:07 → 21:42:18 → 21:42:30
  ───────────────────────────────────  ────────────────────────────────
   Hyperallergic, YTD, anonymous        21:42:11 → 21:42:22 → 21:42:35
  ───────────────────────────────────  ────────────────────────────────
   Alison Roman, YTD, all audiences     13:17:29 → 13:17:40 → 13:17:52

  Those intervals closely match 10-second timeout + retry backoff. Earlier queries remained outstanding when later copies started.

  The likely retry copies consumed 94.93 CPU seconds in incident 1 and 36.97 CPU seconds in incident 2.

  This is a high-confidence inference, rather than confirmed parent/child request tracing. Browser KPI requests also repeated, but the current browser hook disables
  ordinary retries; their exact UI trigger remains unknown.

  ## 5. Which endpoints contribute most?

  These percentages describe logged read CPU, not all host CPU. Baseline means the remainder of the fixed 24-hour window, excluding the two original bursts.

   Endpoint                   Baseline share    Incident 1    Incident 2
  ━━━━━━━━━━━━━━━━━━━━━━━━━  ━━━━━━━━━━━━━━━━  ━━━━━━━━━━━━  ━━━━━━━━━━━━
   api_top_pages                       29.5%         30.0%         33.9%
  ─────────────────────────  ────────────────  ────────────  ────────────
   api_kpis                            21.5%         24.3%         35.4%
  ─────────────────────────  ────────────────  ────────────  ────────────
   api_active_visitors                 19.4%          2.0%          1.5%
  ─────────────────────────  ────────────────  ────────────  ────────────
   api_post_visitor_counts             13.7%          1.2%          0.7%
  ─────────────────────────  ────────────────  ────────────  ────────────
   api_top_sources                      7.3%         24.3%         16.9%
  ─────────────────────────  ────────────────  ────────────  ────────────
   api_top_locations                    6.1%         18.2%         11.5%
  ─────────────────────────  ────────────────  ────────────  ────────────
   query_api                            2.4%            0%            0%

  The four dashboard endpoints together accounted for 96.7% and 97.7% of incident read CPU. The endpoint named in the alert was only part of the workload.

  Active visitors generated approximately 459,000 baseline requests, but each averaged only 6.9 ms CPU. Its cumulative baseline cost is substantial; it did not trigger
  these spikes.

  Outside the selected bursts, the highest site CPU totals were Hyperallergic, Alison Roman, The Race, Tangle, and 404 Media. Those costs were distributed across almost a
  day; during each incident, one site abruptly dominated.

  ## 6. Writes and collateral impact

  Ingestion stayed steady. Reads consumed 544.4 CPU seconds versus roughly 2.46 recorded ingestion CPU seconds during the first burst.

  One correction to my earlier figures: the quoted 7,000–9,000 written rows/minute included writes into multiple derived tables. Actual incoming events were closer to
  1,900–2,200/minute around these bursts.

  The restrictions also affected unrelated tenants:

  - Incident 1: 25 rejected requests across six other sites, plus slower successful requests.
  - Incident 2: four rejected requests across four other sites.

  Background merge/OS CPU is not fully accounted for by these service logs, so the read percentages should not be presented as an exact breakdown of total server
  utilization.

  ### Root cause statement

  Large-site, year-to-date dashboard activity exposed an expensive raw-hit/session-processing path. Multiple queries overlapped, likely compounded by server-side retries,
  producing CPU and memory pressure. Tinybird’s endpoint-wide protection then extended the impact to other sites.

  The triggering workload and mechanism are strongly supported. The earlier September 10 cost increase, exact retry lineage, and Tinybird’s internal thresholds remain open
  questions, documented in the full report (/tmp/tinybird-rca/report.md).

─ Worked for 16m 48s ──────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────

─ Conversation recap ──────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────

  The investigation linked both incidents to overlapping year-to-date analytics queries for large sites, including Hyperallergic on September 14 and Alison Roman. The
  available conversation ends mid-conclusion, so completion status and any remaining follow-up are unclear.
