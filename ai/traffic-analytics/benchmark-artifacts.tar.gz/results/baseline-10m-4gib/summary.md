# Traffic analytics baseline

Measured 5 sequential requests per case after one warm-up. CPU is summed user + system thread time; memory is query-log peak memory.

| Case | HTTP median ms | Engine ms | Rows read | Read MiB | CPU ms | Peak MiB | OK / errors |
|---|---:|---:|---:|---:|---:|---:|---:|
| api_kpis-30d | 360.14 | 348.39 | 3893430 | 181.94 | 840.35 | 664.79 | 5 / 0 |
| api_kpis-history | 4153.50 | 4138.97 | 19999938 | 934.60 | 23586.59 | 2961.74 | 5 / 0 |
| api_top_pages-30d | 475.84 | 430.94 | 11946682 | 1233.69 | 2435.56 | 597.90 | 5 / 0 |
| api_top_pages-history | 3217.72 | 3195.96 | 19999936 | 1610.02 | 20372.39 | 2790.14 | 5 / 0 |
| api_top_sources-30d | 385.46 | 335.49 | 3893428 | 200.00 | 1083.44 | 759.76 | 5 / 0 |
| api_top_sources-history | 3369.28 | 3326.39 | 19999936 | 1027.40 | 21011.51 | 2718.97 | 5 / 0 |
| api_top_locations-30d | 471.04 | 401.70 | 11946682 | 620.07 | 1461.58 | 580.67 | 5 / 0 |
| api_top_locations-history | 2432.05 | 2412.79 | 19999936 | 996.40 | 9765.95 | 2420.35 | 5 / 0 |
| api_top_devices-30d | 261.67 | 236.86 | 3893428 | 209.79 | 919.56 | 756.21 | 5 / 0 |
| api_top_devices-history | 3833.94 | 3817.19 | 19999936 | 1077.65 | 26012.34 | 2796.32 | 5 / 0 |
| api_top_utm_sources-30d | 375.12 | 318.14 | 3893428 | 199.01 | 975.09 | 734.93 | 5 / 0 |
| api_top_utm_sources-history | 3022.11 | 3004.81 | 19999936 | 1022.33 | 17918.65 | 2702.71 | 5 / 0 |
| api_top_utm_mediums-30d | 330.86 | 279.39 | 3893428 | 198.41 | 923.51 | 728.29 | 5 / 0 |
| api_top_utm_mediums-history | 3055.38 | 3035.69 | 19999936 | 1019.24 | 19820.65 | 2713.50 | 5 / 0 |
| api_top_utm_campaigns-30d | 370.57 | 327.11 | 3893428 | 200.73 | 980.96 | 723.46 | 5 / 0 |
| api_top_utm_campaigns-history | 3160.60 | 3144.70 | 19999936 | 1031.16 | 18837.43 | 2730.81 | 5 / 0 |
| api_top_utm_terms-30d | 325.17 | 276.35 | 3893428 | 196.79 | 789.29 | 705.90 | 5 / 0 |
| api_top_utm_terms-history | 2914.96 | 2892.62 | 19999936 | 1010.89 | 16599.40 | 2580.55 | 5 / 0 |
| api_top_utm_contents-30d | 341.90 | 308.58 | 3893428 | 196.79 | 845.91 | 710.19 | 5 / 0 |
| api_top_utm_contents-history | 2992.88 | 2976.96 | 19999936 | 1010.89 | 16684.40 | 2628.99 | 5 / 0 |
| api_kpis-post-30d | 264.91 | 213.49 | 15840113 | 1184.09 | 1339.16 | 337.21 | 5 / 0 |
| api_post_visitor_counts-lifetime | 138.86 | 129.61 | 9999968 | 745.84 | 1030.50 | 224.30 | 5 / 0 |
| api_kpis-source-30d | 411.47 | 399.47 | 5840144 | 290.97 | 1323.92 | 725.92 | 5 / 0 |
| api_kpis-audience-30d | 370.34 | 347.70 | 3893431 | 211.87 | 905.58 | 660.65 | 5 / 0 |
| api_active_visitors-live | 12.16 | 2.71 | 0 | 0.00 | 3.98 | 8.05 | 5 / 0 |
| api_gift_link_visits-lifetime | 12.92 | 4.44 | 0 | 0.00 | 5.18 | 7.06 | 5 / 0 |

See metadata.json for dataset coverage and source hashes; results.json for individual requests, ranges, result hashes, and missing query-log metrics. Explain files contain expanded SQL and index/granule pruning.

Known coverage gaps are recorded in metadata.dataset. Empty-result queries are not representative of populated dimensions. Live visitor requests cannot be replayed at a frozen time.
