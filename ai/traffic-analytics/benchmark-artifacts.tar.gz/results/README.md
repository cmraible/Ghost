# Local traffic analytics experiments

## Canonical baseline

Use `baseline-10m-4gib/` for future comparisons: 10 million total raw events, 9,999,967 hits for the benchmark site, 3,335,234 sessions; local 4 GiB per-query limit. All 156 requests succeeded with matching query logs (26 cases, one warm-up and five measured runs, concurrency 1).

This directory is outside the Ghost repository and is not committed. It contains measurement artifacts, not a backup of the Tinybird database. The synthetic dataset remains in the Docker volumes: preserve those volumes for reproducible comparisons. The generator is not seeded; regenerating 10 million events will not recreate identical data.

- `baseline-10m-4gib/summary.md`: timings, reads, CPU time, memory, success counts.
- `baseline-10m-4gib/results.json`: complete measured samples and query logs, result hashes, metadata.
- `baseline-10m-4gib/manifest.json`: exact endpoint parameters.
- `baseline-10m-4gib/explain/`: expanded SQL and query plans.
- `baseline-10m-4gib/local-settings.json`: ClickHouse settings recorded before the run.
- `baseline-10m-4gib/source-snapshot/`: source copies; all metadata source hashes matched when archived.
- `baseline-10m-4gib/checksums.json`: SHA-256 checksums of baseline artifacts and source copies.
- `baseline/`, `replay/`: earlier 1 million row runs.
- `baseline-10m/`: 10 million row run with the original 2 GB limit, including memory-limit failures.

From the Ghost repository, replay without replacing existing results:

```sh
pnpm data:analytics:benchmark --manifest /home/developer/.codex/visualizations/2026/09/15/01a0a549-7ea0-7250-9f82-9822e9972571/traffic-performance/baseline-10m-4gib/manifest.json --output /tmp/ghost-traffic-candidate-01 --iterations 5
```

Move candidate outputs into this directory for long-term retention. Keep dataset, Docker allocation, query memory limit, parameters and background workload consistent. CPU measurements are summed user/system thread time, not host utilization. Queries for live visitors cannot have a frozen window. The current fixture coverage has no populated gift links, known devices, UTM terms or UTM contents.

## Experiment 1

[Aggregate before calendar join](experiment-01-aggregate-before-calendar/comparison.md): deployed locally; correctness checks passed, but no demonstrated performance improvement. Baseline artifacts remain unchanged.

[Experiment 1 repeat](experiment-01-repeat/comparison.md): same deployment, memory increase reproduced; CPU/latency gains remain inconclusive.

## Experiment 2a

[Unfiltered session fast path](experiment-02-unfiltered-session-fast-path/comparison.md): experiment 1 reverted; clear improvement for explicitly date-bounded requests without attribute filters. Filtered paths retain baseline SQL.

[Deferred member-status rollout](member-status-rollout-note.md): tighten ingestion/status validation and historical-data handling before omitting the default audience filter.

## Experiment 3

[Hourly session summaries](experiment-03-hourly-session-summaries/comparison.md): default audience filter preserved; all results matched, fewer reads, modest full-history memory savings but no clear latency win. Additional summary storage ~163 MiB.

## Experiment 4

[Combined session qualification](experiment-04-combined-session-qualification/comparison.md): current default audience predicate preserved, significant gains in audience/source/base KPIs, all 156 results match. No ingestion or Admin changes required for this candidate.
