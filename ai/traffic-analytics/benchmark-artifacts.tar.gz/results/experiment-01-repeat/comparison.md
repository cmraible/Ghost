# Experiment 1 repeatability check

Same deployed pipe, dataset, full 26-case manifest, one warm-up and five measured rounds, concurrency 1 and 4 GiB query limit. No source edits or deployments were performed for this repeat. Source hashes and dataset metadata match the first experiment. All successful result hashes match the original baseline. All rows/bytes-read medians match the first experiment.

155/156 requests succeeded with QueryFinish logs. One unchanged api_top_devices-history request in round 1 returned HTTP 408 after the local 10-second limit; its exception log is saved separately. All 30 KPI requests succeeded. The benchmark exited 1 because of that timeout.

## Full-history KPI medians

| Metric | Baseline | Experiment 1 | Repeat |
|---|---:|---:|---:|
| HTTP seconds | 4.154 | 3.826 | 3.680 |
| CPU seconds | 23.587 | 22.527 | 21.934 |
| Peak memory GiB | 2.892 | 3.129 | 3.104 |

## Full-history individual sample ranges

| Metric | Baseline min–max | Experiment 1 min–max | Repeat min–max |
|---|---:|---:|---:|
| HTTP seconds | 3.083–4.875 | 2.902–5.033 | 3.323–3.830 |
| CPU seconds | 17.618–29.852 | 17.807–30.681 | 19.668–23.430 |
| Peak memory GiB | 2.863–2.909 | 3.095–3.149 | 3.084–3.149 |

The memory increase is consistent across both experiment runs: baseline samples range 2.863–2.909 GiB; all ten modified-query samples range 3.084–3.149 GiB. CPU and wall time have overlapping baseline/experiment sample ranges. Lower CPU with higher peak memory is possible: CPU is work summed over time, while peak memory is the maximum simultaneous allocation. The changed execution plan can change allocation lifetimes and overlap. That is a plausible explanation, not a proven diagnosis from these logs.

The repeat supports the memory regression more strongly than a CPU/latency gain. Unchanged endpoints also varied across runs; these sequential before/after runs do not isolate machine/cache/scheduling effects.

## All cases: medians

| Case | HTTP ms baseline / first / repeat | CPU ms baseline / first / repeat | Peak MiB baseline / first / repeat |
|---|---:|---:|---:|
| api_kpis-30d | 360.1 / 302.1 / 319.5 | 840.3 / 963.9 / 922.5 | 664.8 / 656.2 / 654.2 |
| api_kpis-history | 4153.5 / 3826.3 / 3679.6 | 23586.6 / 22526.9 / 21934.0 | 2961.7 / 3203.8 / 3178.3 |
| api_top_pages-30d | 475.8 / 391.5 / 387.5 | 2435.6 / 1878.5 / 2087.6 | 597.9 / 591.2 / 599.4 |
| api_top_pages-history | 3217.7 / 3039.1 / 3110.1 | 20372.4 / 18826.0 / 19183.8 | 2790.1 / 2796.0 / 2800.4 |
| api_top_sources-30d | 385.5 / 314.6 / 405.4 | 1083.4 / 981.2 / 1118.6 | 759.8 / 742.7 / 747.7 |
| api_top_sources-history | 3369.3 / 2934.3 / 3127.5 | 21011.5 / 19038.2 / 19417.8 | 2719.0 / 2750.2 / 2776.5 |
| api_top_locations-30d | 471.0 / 362.1 / 316.0 | 1461.6 / 1236.2 / 1194.6 | 580.7 / 574.6 / 575.2 |
| api_top_locations-history | 2432.1 / 2045.5 / 1664.5 | 9765.9 / 9365.1 / 7835.0 | 2420.4 / 2412.4 / 2407.2 |
| api_top_devices-30d | 261.7 / 246.8 / 249.7 | 919.6 / 924.0 / 838.8 | 756.2 / 758.4 / 756.4 |
| api_top_devices-history | 3833.9 / 3302.3 / 3124.6 | 26012.3 / 22949.1 / 21701.3 | 2796.3 / 2790.4 / 2824.1 |
| api_top_utm_sources-30d | 375.1 / 299.4 / 321.0 | 975.1 / 846.4 / 1027.3 | 734.9 / 735.2 / 730.1 |
| api_top_utm_sources-history | 3022.1 / 2854.0 / 2930.2 | 17918.7 / 16939.1 / 18025.1 | 2702.7 / 2752.1 / 2725.3 |
| api_top_utm_mediums-30d | 330.9 / 275.3 / 450.5 | 923.5 / 862.7 / 1026.3 | 728.3 / 729.2 / 725.5 |
| api_top_utm_mediums-history | 3055.4 / 2803.1 / 2816.2 | 19820.6 / 17017.9 / 17402.4 | 2713.5 / 2742.7 / 2735.8 |
| api_top_utm_campaigns-30d | 370.6 / 328.5 / 340.0 | 981.0 / 860.5 / 914.0 | 723.5 / 717.8 / 731.3 |
| api_top_utm_campaigns-history | 3160.6 / 2968.4 / 2704.4 | 18837.4 / 17449.8 / 16391.2 | 2730.8 / 2768.8 / 2723.0 |
| api_top_utm_terms-30d | 325.2 / 311.8 / 271.8 | 789.3 / 770.1 / 735.5 | 705.9 / 708.8 / 715.0 |
| api_top_utm_terms-history | 2915.0 / 2462.3 / 2438.5 | 16599.4 / 15123.7 / 14262.4 | 2580.6 / 2587.6 / 2619.7 |
| api_top_utm_contents-30d | 341.9 / 279.6 / 227.4 | 845.9 / 736.5 / 676.3 | 710.2 / 712.5 / 705.1 |
| api_top_utm_contents-history | 2992.9 / 2408.3 / 2421.0 | 16684.4 / 14029.0 / 14821.2 | 2629.0 / 2644.6 / 2649.8 |
| api_kpis-post-30d | 264.9 / 244.3 / 263.1 | 1339.2 / 1265.0 / 1344.0 | 337.2 / 336.9 / 336.6 |
| api_post_visitor_counts-lifetime | 138.9 / 117.1 / 131.5 | 1030.5 / 906.3 / 1022.5 | 224.3 / 225.2 / 228.0 |
| api_kpis-source-30d | 411.5 / 307.6 / 347.2 | 1323.9 / 1205.2 / 1329.2 | 725.9 / 728.8 / 726.5 |
| api_kpis-audience-30d | 370.3 / 296.6 / 324.4 | 905.6 / 860.7 / 940.7 | 660.7 / 656.9 / 652.9 |
| api_active_visitors-live | 12.2 / 11.5 / 12.6 | 4.0 / 3.6 / 3.9 | 8.0 / 8.0 / 8.0 |
| api_gift_link_visits-lifetime | 12.9 / 12.7 / 13.3 | 5.2 / 5.3 / 5.2 | 7.1 / 7.1 / 7.1 |

Medians exclude failed requests; all failures remain in results.json and exception logs. CPU is user+system thread time, not CPU utilization. The unchanged pipe remains deployed locally.
