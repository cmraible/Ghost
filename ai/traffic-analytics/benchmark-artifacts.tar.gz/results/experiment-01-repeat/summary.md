# Traffic analytics baseline

Measured 5 sequential requests per case after one warm-up. CPU is summed user + system thread time; memory is query-log peak memory.

| Case | HTTP median ms | Engine ms | Rows read | Read MiB | CPU ms | Peak MiB | OK / errors |
|---|---:|---:|---:|---:|---:|---:|---:|
| api_kpis-30d | 319.49 | 309.12 | 3893429 | 181.94 | 922.52 | 654.23 | 5 / 0 |
| api_kpis-history | 3679.61 | 3668.26 | 19999937 | 934.60 | 21933.98 | 3178.34 | 5 / 0 |
| api_top_pages-30d | 387.47 | 337.83 | 11946682 | 1233.69 | 2087.64 | 599.43 | 5 / 0 |
| api_top_pages-history | 3110.12 | 3065.55 | 19999936 | 1610.02 | 19183.78 | 2800.39 | 5 / 0 |
| api_top_sources-30d | 405.36 | 337.13 | 3893428 | 200.00 | 1118.59 | 747.73 | 5 / 0 |
| api_top_sources-history | 3127.45 | 3111.54 | 19999936 | 1027.40 | 19417.80 | 2776.53 | 5 / 0 |
| api_top_locations-30d | 316.04 | 265.65 | 11946682 | 620.07 | 1194.62 | 575.23 | 5 / 0 |
| api_top_locations-history | 1664.47 | 1653.47 | 19999936 | 996.40 | 7835.04 | 2407.21 | 5 / 0 |
| api_top_devices-30d | 249.73 | 223.42 | 3893428 | 209.79 | 838.80 | 756.41 | 5 / 0 |
| api_top_devices-history | 3124.63 | 3112.28 | 19999936 | 1077.65 | 21701.34 | 2824.06 | 4 / 1 |
| api_top_utm_sources-30d | 320.98 | 272.64 | 3893428 | 199.01 | 1027.27 | 730.12 | 5 / 0 |
| api_top_utm_sources-history | 2930.22 | 2916.39 | 19999936 | 1022.33 | 18025.11 | 2725.26 | 5 / 0 |
| api_top_utm_mediums-30d | 450.46 | 316.19 | 3893428 | 198.41 | 1026.28 | 725.54 | 5 / 0 |
| api_top_utm_mediums-history | 2816.19 | 2797.11 | 19999936 | 1019.24 | 17402.36 | 2735.76 | 5 / 0 |
| api_top_utm_campaigns-30d | 340.03 | 278.61 | 3893428 | 200.73 | 914.03 | 731.33 | 5 / 0 |
| api_top_utm_campaigns-history | 2704.40 | 2689.71 | 19999936 | 1031.16 | 16391.17 | 2722.97 | 5 / 0 |
| api_top_utm_terms-30d | 271.78 | 229.94 | 3893428 | 196.79 | 735.53 | 714.97 | 5 / 0 |
| api_top_utm_terms-history | 2438.53 | 2424.94 | 19999936 | 1010.89 | 14262.39 | 2619.74 | 5 / 0 |
| api_top_utm_contents-30d | 227.44 | 192.05 | 3893428 | 196.79 | 676.31 | 705.09 | 5 / 0 |
| api_top_utm_contents-history | 2421.01 | 2406.03 | 19999936 | 1010.89 | 14821.22 | 2649.80 | 5 / 0 |
| api_kpis-post-30d | 263.14 | 222.12 | 15840112 | 1184.09 | 1344.04 | 336.61 | 5 / 0 |
| api_post_visitor_counts-lifetime | 131.54 | 118.50 | 9999968 | 745.84 | 1022.54 | 227.99 | 5 / 0 |
| api_kpis-source-30d | 347.20 | 335.57 | 5840143 | 290.97 | 1329.22 | 726.52 | 5 / 0 |
| api_kpis-audience-30d | 324.40 | 302.56 | 3893430 | 211.87 | 940.67 | 652.91 | 5 / 0 |
| api_active_visitors-live | 12.56 | 2.82 | 0 | 0.00 | 3.95 | 8.05 | 5 / 0 |
| api_gift_link_visits-lifetime | 13.28 | 4.38 | 0 | 0.00 | 5.21 | 7.05 | 5 / 0 |

See metadata.json for dataset coverage and source hashes; results.json for individual requests, ranges, result hashes, and missing query-log metrics. Explain files contain expanded SQL and index/granule pruning.

Known coverage gaps are recorded in metadata.dataset. Empty-result queries are not representative of populated dimensions. Live visitor requests cannot be replayed at a frozen time.
