# Experiment 1: aggregate before calendar join

## Conclusion

No demonstrated performance improvement. The deployed plan removes one calendar join, but full-history KPI median peak memory increased 8.2%; its 7.9% lower HTTP duration is within the broader improvement seen on unchanged endpoints. Keep this as an experimental result, not evidence for shipping an optimization.

## Setup and validation

- Same full 26-case manifest, one warm-up and five measured rounds, concurrency 1, 4 GiB query limit, max_threads=16, hash joins.
- Dataset metadata is identical: 9,999,967 benchmark-site hits and 3,335,234 sessions. Only endpoints/api_kpis.pipe changed among hashed Tinybird sources.
- Explicit local build succeeded and reported only api_kpis.pipe changed. Saved explain confirms the full-history plan has two Join nodes instead of three.
- All 23 existing api_kpis test cases passed, including date ranges, current-hour truncation, non-UTC timezone, location/member/post/path/source/UTM/device/gift filters and missing date_to.
- All 30 KPI requests passed, including warm-up. Every successful benchmark result hash matched its baseline case.
- Overall: 153 successes / 3 failures. In round 4, api_top_sources-history, api_top_devices-history and api_top_utm_sources-history returned HTTP 408 at the local 10-second execution limit. These pipes were unchanged. Failures are preserved; the runner exited 1.
- All 156 requests have corresponding logs: 153 successful QueryFinish entries in results.json and 3 exception entries in failed-query-logs.json.
- git diff --check passed. No repository-wide application test suite was run for this isolated Tinybird SQL experiment.

## KPI medians

| Case | HTTP before → after (ms) | HTTP change | CPU before → after (ms) | Peak before → after (MiB) | Peak change |
|---|---:|---:|---:|---:|---:|
| api_kpis-30d | 360.1 → 302.1 | -16.1% | 840.3 → 963.9 | 664.8 → 656.2 | -1.3% |
| api_kpis-history | 4153.5 → 3826.3 | -7.9% | 23586.6 → 22526.9 | 2961.7 → 3203.8 | +8.2% |
| api_kpis-post-30d | 264.9 → 244.3 | -7.8% | 1339.2 → 1265.0 | 337.2 → 336.9 | -0.1% |
| api_kpis-source-30d | 411.5 → 307.6 | -25.2% | 1323.9 → 1205.2 | 725.9 → 728.8 | +0.4% |
| api_kpis-audience-30d | 370.3 → 296.6 | -19.9% | 905.6 → 860.7 | 660.7 → 656.9 | -0.6% |

Both hit scans remain unchanged. Each KPI case reports one fewer row and one fewer byte read, corresponding to the removed generated-calendar branch’s SystemOne row.

Across unchanged history cases, median HTTP changes ranged from -19.5% to -5.6%. These successful-response medians exclude the three timeouts. They show that raw before/after duration changes cannot be attributed solely to this edit.

## Artifacts

- summary.md and results.json: full endpoint matrix, all samples and successful query logs.
- failed-query-logs.json: timeout diagnostics.
- explain/: deployed expanded SQL and plans.
- source-snapshot/: exact candidate source and benchmark runner.
- change.diff: experimental code change.
- manifest.json, metadata.json, local-settings.json and checksums.json: reproducibility and integrity.
