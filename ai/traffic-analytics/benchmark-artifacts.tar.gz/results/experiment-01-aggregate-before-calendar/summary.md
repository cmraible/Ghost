# Traffic analytics baseline

Measured 5 sequential requests per case after one warm-up. CPU is summed user + system thread time; memory is query-log peak memory.

| Case | HTTP median ms | Engine ms | Rows read | Read MiB | CPU ms | Peak MiB | OK / errors |
|---|---:|---:|---:|---:|---:|---:|---:|
| api_kpis-30d | 302.07 | 292.31 | 3893429 | 181.94 | 963.94 | 656.17 | 5 / 0 |
| api_kpis-history | 3826.29 | 3803.63 | 19999937 | 934.60 | 22526.90 | 3203.78 | 5 / 0 |
| api_top_pages-30d | 391.50 | 327.70 | 11946682 | 1233.69 | 1878.51 | 591.21 | 5 / 0 |
| api_top_pages-history | 3039.10 | 3024.33 | 19999936 | 1610.02 | 18825.99 | 2795.96 | 5 / 0 |
| api_top_sources-30d | 314.61 | 262.53 | 3893428 | 200.00 | 981.24 | 742.70 | 5 / 0 |
| api_top_sources-history | 2934.29 | 2897.27 | 19999936 | 1027.40 | 19038.24 | 2750.25 | 4 / 1 |
| api_top_locations-30d | 362.14 | 314.13 | 11946682 | 620.07 | 1236.25 | 574.57 | 5 / 0 |
| api_top_locations-history | 2045.50 | 2031.44 | 19999936 | 996.40 | 9365.09 | 2412.38 | 5 / 0 |
| api_top_devices-30d | 246.85 | 222.38 | 3893428 | 209.79 | 923.97 | 758.36 | 5 / 0 |
| api_top_devices-history | 3302.32 | 3287.42 | 19999936 | 1077.65 | 22949.09 | 2790.43 | 4 / 1 |
| api_top_utm_sources-30d | 299.38 | 248.42 | 3893428 | 199.01 | 846.44 | 735.18 | 5 / 0 |
| api_top_utm_sources-history | 2854.01 | 2837.08 | 19999936 | 1022.33 | 16939.08 | 2752.10 | 4 / 1 |
| api_top_utm_mediums-30d | 275.28 | 235.37 | 3893428 | 198.41 | 862.67 | 729.24 | 5 / 0 |
| api_top_utm_mediums-history | 2803.06 | 2792.35 | 19999936 | 1019.24 | 17017.91 | 2742.68 | 5 / 0 |
| api_top_utm_campaigns-30d | 328.47 | 281.12 | 3893428 | 200.73 | 860.53 | 717.85 | 5 / 0 |
| api_top_utm_campaigns-history | 2968.39 | 2952.68 | 19999936 | 1031.16 | 17449.77 | 2768.80 | 5 / 0 |
| api_top_utm_terms-30d | 311.84 | 256.21 | 3893428 | 196.79 | 770.10 | 708.82 | 5 / 0 |
| api_top_utm_terms-history | 2462.30 | 2442.82 | 19999936 | 1010.89 | 15123.66 | 2587.58 | 5 / 0 |
| api_top_utm_contents-30d | 279.64 | 236.99 | 3893428 | 196.79 | 736.54 | 712.53 | 5 / 0 |
| api_top_utm_contents-history | 2408.28 | 2393.95 | 19999936 | 1010.89 | 14029.00 | 2644.61 | 5 / 0 |
| api_kpis-post-30d | 244.31 | 202.48 | 15840112 | 1184.09 | 1265.02 | 336.91 | 5 / 0 |
| api_post_visitor_counts-lifetime | 117.14 | 105.15 | 9999968 | 745.84 | 906.31 | 225.24 | 5 / 0 |
| api_kpis-source-30d | 307.63 | 295.22 | 5840143 | 290.97 | 1205.25 | 728.82 | 5 / 0 |
| api_kpis-audience-30d | 296.61 | 282.31 | 3893430 | 211.87 | 860.73 | 656.93 | 5 / 0 |
| api_active_visitors-live | 11.49 | 2.72 | 0 | 0.00 | 3.56 | 8.05 | 5 / 0 |
| api_gift_link_visits-lifetime | 12.67 | 4.41 | 0 | 0.00 | 5.28 | 7.05 | 5 / 0 |

See metadata.json for dataset coverage and source hashes; results.json for individual requests, ranges, result hashes, and missing query-log metrics. Explain files contain expanded SQL and index/granule pruning.

Known coverage gaps are recorded in metadata.dataset. Empty-result queries are not representative of populated dimensions. Live visitor requests cannot be replayed at a frozen time.
