# Traffic analytics baseline

Measured 5 sequential requests per case after one warm-up. CPU is summed user + system thread time; memory is query-log peak memory.

| Case | HTTP median ms | Engine ms | Rows read | Read MiB | CPU ms | Peak MiB | OK / errors |
|---|---:|---:|---:|---:|---:|---:|---:|
| api_kpis-30d | 272.45 | 263.17 | 3893430 | 181.94 | 739.14 | 658.07 | 5 / 0 |
| api_kpis-history | n/a | n/a | n/a | n/a | n/a | n/a | 0 / 5 |
| api_top_pages-30d | 285.08 | 274.60 | 11946682 | 1233.69 | 1613.83 | 594.69 | 5 / 0 |
| api_top_pages-history | n/a | n/a | n/a | n/a | n/a | n/a | 0 / 5 |
| api_top_sources-30d | 225.61 | 213.24 | 3893428 | 200.00 | 815.85 | 752.74 | 5 / 0 |
| api_top_sources-history | n/a | n/a | n/a | n/a | n/a | n/a | 0 / 5 |
| api_top_locations-30d | 235.03 | 223.21 | 11946682 | 620.07 | 1012.24 | 563.15 | 5 / 0 |
| api_top_locations-history | n/a | n/a | n/a | n/a | n/a | n/a | 0 / 5 |
| api_top_devices-30d | 206.45 | 195.68 | 3893428 | 209.79 | 813.79 | 744.10 | 5 / 0 |
| api_top_devices-history | n/a | n/a | n/a | n/a | n/a | n/a | 0 / 5 |
| api_top_utm_sources-30d | 223.29 | 211.16 | 3893428 | 199.01 | 832.43 | 727.46 | 5 / 0 |
| api_top_utm_sources-history | n/a | n/a | n/a | n/a | n/a | n/a | 0 / 5 |
| api_top_utm_mediums-30d | 223.53 | 211.17 | 3893428 | 198.41 | 832.70 | 728.21 | 5 / 0 |
| api_top_utm_mediums-history | n/a | n/a | n/a | n/a | n/a | n/a | 0 / 5 |
| api_top_utm_campaigns-30d | 216.97 | 206.95 | 3893428 | 200.73 | 746.70 | 717.90 | 5 / 0 |
| api_top_utm_campaigns-history | n/a | n/a | n/a | n/a | n/a | n/a | 0 / 5 |
| api_top_utm_terms-30d | 208.72 | 198.94 | 3893428 | 196.79 | 652.90 | 710.74 | 5 / 0 |
| api_top_utm_terms-history | n/a | n/a | n/a | n/a | n/a | n/a | 0 / 5 |
| api_top_utm_contents-30d | 194.07 | 183.63 | 3893428 | 196.79 | 665.45 | 704.83 | 5 / 0 |
| api_top_utm_contents-history | n/a | n/a | n/a | n/a | n/a | n/a | 0 / 5 |
| api_kpis-post-30d | 218.25 | 205.58 | 15840113 | 1184.09 | 1299.75 | 335.16 | 5 / 0 |
| api_post_visitor_counts-lifetime | 122.34 | 110.83 | 9999968 | 745.84 | 896.95 | 222.66 | 5 / 0 |
| api_kpis-source-30d | 295.03 | 284.18 | 5840144 | 290.97 | 1173.18 | 728.50 | 5 / 0 |
| api_kpis-audience-30d | 281.51 | 267.44 | 3893431 | 211.87 | 826.82 | 659.19 | 5 / 0 |
| api_active_visitors-live | 12.68 | 3.98 | 24437 | 1.14 | 6.89 | 8.05 | 5 / 0 |
| api_gift_link_visits-lifetime | 11.43 | 3.83 | 0 | 0.00 | 4.39 | 7.05 | 5 / 0 |

See metadata.json for dataset coverage and source hashes; results.json for individual requests, ranges, result hashes, and missing query-log metrics. Explain files contain expanded SQL and index/granule pruning.

Known coverage gaps are recorded in metadata.dataset. Empty-result queries are not representative of populated dimensions. Live visitor requests cannot be replayed at a frozen time.
