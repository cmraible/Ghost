# 10 million row baseline vs 1 million rows

Same 26 cases and exact manifest parameters, one warm-up plus five measured requests per case, concurrency 1. No pipe changes. Local warm-cache results; this is not a production capacity estimate.

96/156 total requests succeeded; 60/156 returned HTTP 400 MEMORY_LIMIT_EXCEEDED (including warm-ups). All 10 history cases failed all five measured attempts. All 16 other cases passed all five. All 156 requests have matching query logs: 96 QueryFinish plus 60 ExceptionWhileProcessing entries. Failed-query logs are saved separately in failed-query-logs.json.

The exception logs report a 1.86 GiB per-query maximum; failures occurred while executing FillingRightJoinSide. Peak recorded memory can be lower than the rejected allocation. Failure durations below measure time until the error response, not successful query execution.

| Case | Previous HTTP ms | New HTTP ms | Ratio | Outcome | Rows read | Read MiB | CPU ms | Peak MiB |
|---|---:|---:|---:|---|---:|---:|---:|---:|
| api_kpis-30d | 45.13 | 272.45 | 6.04× | Success, 5/5 | 3893430 | 181.94 | 739.14 | 658.07 |
| api_kpis-history | 128.67 | 448.28 | — | Memory limit, 5/5 | 6558951 | 306.50 | 889.47 | 1456.13 |
| api_top_pages-30d | 45.15 | 285.08 | 6.31× | Success, 5/5 | 11946682 | 1233.69 | 1613.83 | 594.69 |
| api_top_pages-history | 91.77 | 499.67 | — | Memory limit, 5/5 | 6542565 | 305.74 | 965.67 | 1448.50 |
| api_top_sources-30d | 37.73 | 225.61 | 5.98× | Success, 5/5 | 3893428 | 200.00 | 815.85 | 752.74 |
| api_top_sources-history | 94.51 | 431.93 | — | Memory limit, 5/5 | 6544036 | 305.80 | 926.46 | 1449.37 |
| api_top_locations-30d | 35.83 | 235.03 | 6.56× | Success, 5/5 | 11946682 | 620.07 | 1012.24 | 563.15 |
| api_top_locations-history | 81.20 | 421.41 | — | Memory limit, 5/5 | 6557957 | 306.45 | 880.57 | 1434.94 |
| api_top_devices-30d | 36.64 | 206.45 | 5.63× | Success, 5/5 | 3893428 | 209.79 | 813.79 | 744.10 |
| api_top_devices-history | 93.33 | 465.33 | — | Memory limit, 5/5 | 6544036 | 305.80 | 882.51 | 1452.76 |
| api_top_utm_sources-30d | 40.56 | 223.29 | 5.51× | Success, 5/5 | 3893428 | 199.01 | 832.43 | 727.46 |
| api_top_utm_sources-history | 88.88 | 438.69 | — | Memory limit, 5/5 | 6544038 | 305.80 | 880.98 | 1449.47 |
| api_top_utm_mediums-30d | 37.31 | 223.53 | 5.99× | Success, 5/5 | 3893428 | 198.41 | 832.70 | 728.21 |
| api_top_utm_mediums-history | 90.95 | 455.78 | — | Memory limit, 5/5 | 6559428 | 306.52 | 945.06 | 1427.80 |
| api_top_utm_campaigns-30d | 45.99 | 216.97 | 4.72× | Success, 5/5 | 3893428 | 200.73 | 746.70 | 717.90 |
| api_top_utm_campaigns-history | 98.00 | 398.96 | — | Memory limit, 5/5 | 6544177 | 305.81 | 846.93 | 1450.05 |
| api_top_utm_terms-30d | 37.45 | 208.72 | 5.57× | Success, 5/5 | 3893428 | 196.79 | 652.90 | 710.74 |
| api_top_utm_terms-history | 87.88 | 432.57 | — | Memory limit, 5/5 | 6543046 | 305.76 | 890.23 | 1446.35 |
| api_top_utm_contents-30d | 41.09 | 194.07 | 4.72× | Success, 5/5 | 3893428 | 196.79 | 665.45 | 704.83 |
| api_top_utm_contents-history | 90.58 | 469.96 | — | Memory limit, 5/5 | 6544036 | 305.80 | 910.75 | 1439.61 |
| api_kpis-post-30d | 65.73 | 218.25 | 3.32× | Success, 5/5 | 15840113 | 1184.09 | 1299.75 | 335.16 |
| api_post_visitor_counts-lifetime | 38.41 | 122.34 | 3.19× | Success, 5/5 | 9999968 | 745.84 | 896.95 | 222.66 |
| api_kpis-source-30d | 65.37 | 295.03 | 4.51× | Success, 5/5 | 5840144 | 290.97 | 1173.18 | 728.50 |
| api_kpis-audience-30d | 49.26 | 281.51 | 5.71× | Success, 5/5 | 3893431 | 211.87 | 826.82 | 659.19 |
| api_active_visitors-live | 10.74 | 12.68 | 1.18× | Success, 5/5 | 24437 | 1.14 | 6.89 | 8.05 |
| api_gift_link_visits-lifetime | 11.83 | 11.43 | 0.97× | Success, 5/5 | 0 | 0.00 | 4.39 | 7.05 |

CPU is summed user + system thread time, not host CPU utilization. Rows/bytes can include multiple scans. Dataset coverage still lacks populated gift links, known devices, UTM terms and UTM contents. The live-visitor window moves with time.
