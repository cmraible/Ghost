# Deferred improvement: omit the default member-status filter

Decision recorded 2026-09-16 at the user's request.

Experiment 2a demonstrated a worthwhile optimization: for explicitly date-bounded api_kpis requests without attribute filters, skipping the redundant qualification scan reduced full-history HTTP median from 4.15 s to 0.87 s, CPU from 23.59 s to 3.41 s, and peak memory from 2.89 GiB to 0.98 GiB, with matching results.

Ghost Admin currently sends member_status=undefined,free,paid even when the user has not selected an audience filter. The pipe expands paid to include comped and gift. This prevents the default Admin view from using the fast path.

Rollout prerequisite agreed here: tighten member_status validation/normalization across ingestion and the Tinybird data contract before making no user-selected audience filter mean no member_status query parameter. Define accepted values, public-visitor representation (the literal string undefined), and handling of missing/unexpected values. Account for historical data and verify that all-audience results remain consistent. Coordinate ingestion/proxy/tracker/pipe changes wherever that contract is enforced; the exact component changes still need investigation.

This is a correctness/rollout prerequisite, not an API compatibility requirement: existing pipes already accept an omitted member_status parameter. The large performance gain additionally requires the api_kpis fast path. Admin must omit the URL key entirely, not serialize JavaScript undefined as member_status=undefined (which means public visitors only). Explicit audience selections must retain their predicates.

Status: valid and worthwhile, deferred pending the validation/data-contract work. No Admin, tracker or TrafficAnalytics ingestion behavior has been changed. Experiment 2 source/results are preserved locally; later experiments should be compared independently against the original baseline.
