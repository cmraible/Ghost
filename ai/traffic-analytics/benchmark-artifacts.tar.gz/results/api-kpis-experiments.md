# api_kpis: hypotheses for experiments

Status: initial hypotheses below are retained for reference. Experiments 1 and 2a have now been run; see the baseline index for their results. Experiment 2a rollout is deferred pending the member-status contract work recorded in member-status-rollout-note.md.

## Current data flow

1. analytics_events: raw JSON payload plus timestamp, site_uuid and session_id. MergeTree, monthly timestamp partitions, sorted by (site_uuid, timestamp).
2. mv_hits: actual ingestion-time materialized pipe. Keeps page_hit events, extracts typed payload columns and normalizes source/device. Writes _mv_hits.
3. _mv_hits: one row per hit, monthly partitions, sorted by (site_uuid, timestamp, session_id). JSON extraction is already out of the API request path.
4. mv_session_data: ordinary query-time pipe, despite its name. Applies supplied date bounds BEFORE grouping by site/session; computes count, min/max timestamp, first-hit source/device/UTMs with argMin. Computes bounce and duration from those in-range hits.
5. filtered_sessions: another hit scan produces DISTINCT session IDs with at least one hit satisfying the combined hit predicates. With source/device/UTM filters, it also executes mv_session_data to test first-in-range-hit attributes.
6. api_kpis: joins session metrics to qualifying IDs, joins the session rows to the generated date series, then aggregates into daily/hourly KPIs. Finally left joins totals onto the date series to fill gaps. Post/path/gift filters also execute pathname_pageviews: another hit scan without explicit timestamp bounds, joined to the date series and qualifying IDs.

The endpoint README describes materialized session states, but that description does not match the active unsuffixed pipes. The _v2 materialized session pipe and API are explicitly marked unused.

## Baseline evidence

The canonical baseline is baseline-10m-4gib. Full-history KPI median: 4.154 s HTTP, 23.587 s summed CPU time, 19,999,938 rows, 934.60 MiB read, 2,961.74 MiB peak memory. The saved plan shows two hit reads plus session-ID and calendar joins. The earlier 2 GB run failed while executing FillingRightJoinSide; this identifies join building, but does not prove which join is responsible for the peak.

Thirty-day base KPI: 3,893,430 rows, 360 ms HTTP, 665 MiB peak. Source-filtered KPI: 5,840,144 rows, 411 ms HTTP, 726 MiB peak; its plan has three hit reads and repeated session aggregation. Post-filtered KPI: 15,840,113 rows, 265 ms HTTP, 1,184 MiB read; the pageview branch has no timestamp partition/index restriction.

## Priority 1: Aggregate before joining the calendar

Change the data node to group session_metrics directly by its date, then use the existing final calendar LEFT JOIN to fill zeros. This removes the intermediate calendar INNER JOIN whose right input contains millions of session rows. Retain the current visits aggregate, truncation, timezone bucketing and final calendar bounds.

Hypothesis: substantially lower peak memory and CPU on full-history requests without changing the hit schema or ingestion. Rows read may remain unchanged; reduced memory and join work are the main signals. Existing plans motivate this, but only an experiment can establish whether this join dominates.

Compare history, 30-day, source and post cases; verify exact output equivalence and single-day/current-hour, timezone/DST and empty-period behavior. Do not combine this first experiment with other join changes.

## Priority 2: Qualify sessions within their aggregation

Start with a no-attribute-filter branch: when explicit date bounds align, every grouped session already qualifies, so omit the DISTINCT hit scan and filtered_sessions join. The target is one hit scan instead of two for base KPI requests (roughly 10 million instead of 20 million history rows).

Then independently extend the hypothesis to filtered requests: compute countIf(combined hit predicates) during session aggregation and apply > 0 after grouping; apply session-level filters to the existing argMin outputs. Keep counting ALL in-range hits for the qualifying session's pageviews/bounce/duration. For source-only filtering this targets one session aggregation/scan instead of three hit scans. More predicate columns may offset some savings and should be measured.

Do not push source or member-status predicates into the raw-hit WHERE: that changes session qualification and session metrics. Combined hit filters must match the same hit. Defaults are asymmetric today: filtered_sessions defaults missing dates to seven days, but mv_session_data only applies explicitly supplied bounds; handle default/one-sided date cases separately before extending the fast path. Keep changes api_kpis-specific initially because filtered_sessions is shared.

## Priority 3: Materialize mergeable session summaries

Largest long-term ceiling, but more effort and semantic risk. Prototype date/time-bucketed per-session states for count, min/max timestamp and first-hit attributes, then merge only the requested window. Consider a raw-hit fallback for partial boundary buckets. Existing unused _v2 definitions are reference material, not an automatic replacement.

Hypothesis: less query-time aggregation over raw hits, with repeated dashboards reading compact states. Measure query CPU/memory/bytes AND ingestion/storage overhead. This dataset averages only about three hits per session, so session-level compression alone is limited; do not assume an order-of-magnitude speedup.

A lifetime session summary changes current semantics: today range clipping happens before computing pageviews, bounce, duration and first-hit attribution. Preserve sessions crossing midnight/range edges, timezone/DST behavior, late/out-of-order arrivals and hit-level qualification. Arbitrary location/member/post/gift filters may still require raw hits or additional state. Do not average precomputed bounce rates/durations without appropriate counts; merge session states first.

## Validation when experiments are authorized

Run one candidate at a time with the same dataset, parameters and 4 GiB limit. Compare result hashes and full rows when they differ; retain current uniqDistinct behavior rather than quietly switching to exact count or another approximation. Use existing api_kpis fixtures and add targeted boundary and attribution correctness cases before accepting a change. Include selective audience filters (the baseline audience case includes all generated statuses), populated gift/UTM/device dimensions and non-UTC windows: these are coverage gaps in the current performance fixture.

A further scoped opportunity inside a future post/path experiment is adding explicit timezone-aware timestamp bounds to pathname_pageviews, whose current 30-day query scans all history. Keep that separate from the three experiments above to attribute gains clearly.
