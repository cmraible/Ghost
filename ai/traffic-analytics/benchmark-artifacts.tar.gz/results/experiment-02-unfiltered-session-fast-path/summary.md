# Traffic analytics baseline

Measured 5 sequential requests per case after one warm-up. CPU is summed user + system thread time; memory is query-log peak memory.

| Case | HTTP median ms | Engine ms | Rows read | Read MiB | CPU ms | Peak MiB | OK / errors |
|---|---:|---:|---:|---:|---:|---:|---:|
| api_kpis-30d | 165.90 | 155.12 | 1946716 | 90.97 | 540.15 | 211.31 | 5 / 0 |
| api_kpis-history | 871.49 | 862.14 | 9999970 | 467.30 | 3407.12 | 1002.37 | 5 / 0 |
| api_top_pages-30d | 366.11 | 356.43 | 11946682 | 1233.69 | 1863.38 | 593.95 | 5 / 0 |
| api_top_pages-history | 3275.38 | 3258.90 | 19999936 | 1610.02 | 21151.59 | 2787.46 | 5 / 0 |
| api_top_sources-30d | 303.53 | 276.97 | 3893428 | 200.00 | 945.95 | 756.99 | 5 / 0 |
| api_top_sources-history | 3268.11 | 3199.30 | 19999936 | 1027.40 | 19540.06 | 2727.71 | 5 / 0 |
| api_top_locations-30d | 342.24 | 297.53 | 11946682 | 620.07 | 1139.95 | 577.25 | 5 / 0 |
| api_top_locations-history | 2043.42 | 2018.76 | 19999936 | 996.40 | 8699.56 | 2417.16 | 5 / 0 |
| api_top_devices-30d | 263.63 | 240.84 | 3893428 | 209.79 | 936.49 | 751.87 | 5 / 0 |
| api_top_devices-history | 3738.96 | 3722.46 | 19999936 | 1077.65 | 26107.66 | 2822.27 | 5 / 0 |
| api_top_utm_sources-30d | 376.96 | 296.75 | 3893428 | 199.01 | 1031.45 | 727.03 | 5 / 0 |
| api_top_utm_sources-history | 3017.24 | 2996.25 | 19999936 | 1022.33 | 18394.92 | 2713.62 | 5 / 0 |
| api_top_utm_mediums-30d | 311.54 | 272.36 | 3893428 | 198.41 | 928.84 | 731.61 | 5 / 0 |
| api_top_utm_mediums-history | 3139.70 | 3128.28 | 19999936 | 1019.24 | 19581.25 | 2712.48 | 5 / 0 |
| api_top_utm_campaigns-30d | 380.52 | 315.82 | 3893428 | 200.73 | 991.74 | 735.35 | 5 / 0 |
| api_top_utm_campaigns-history | 2813.80 | 2801.20 | 19999936 | 1031.16 | 17962.83 | 2731.56 | 4 / 1 |
| api_top_utm_terms-30d | 265.75 | 220.54 | 3893428 | 196.79 | 777.34 | 706.36 | 5 / 0 |
| api_top_utm_terms-history | 2529.98 | 2515.57 | 19999936 | 1010.89 | 15819.93 | 2628.81 | 5 / 0 |
| api_top_utm_contents-30d | 294.18 | 255.04 | 3893428 | 196.79 | 737.85 | 705.27 | 5 / 0 |
| api_top_utm_contents-history | 2630.57 | 2619.05 | 19999936 | 1010.89 | 16418.78 | 2588.81 | 5 / 0 |
| api_kpis-post-30d | 277.85 | 241.84 | 15840113 | 1184.09 | 1425.18 | 334.94 | 5 / 0 |
| api_post_visitor_counts-lifetime | 152.60 | 141.06 | 9999968 | 745.84 | 1200.67 | 221.11 | 5 / 0 |
| api_kpis-source-30d | 402.38 | 388.45 | 5840144 | 290.97 | 1383.50 | 736.58 | 5 / 0 |
| api_kpis-audience-30d | 338.59 | 327.49 | 3893431 | 211.87 | 888.33 | 663.95 | 5 / 0 |
| api_active_visitors-live | 13.54 | 3.99 | 0 | 0.00 | 5.30 | 8.05 | 5 / 0 |
| api_gift_link_visits-lifetime | 14.80 | 5.67 | 0 | 0.00 | 6.36 | 7.05 | 5 / 0 |

See metadata.json for dataset coverage and source hashes; results.json for individual requests, ranges, result hashes, and missing query-log metrics. Explain files contain expanded SQL and index/granule pruning.

Known coverage gaps are recorded in metadata.dataset. Empty-result queries are not representative of populated dimensions. Live visitor requests cannot be replayed at a frozen time.
