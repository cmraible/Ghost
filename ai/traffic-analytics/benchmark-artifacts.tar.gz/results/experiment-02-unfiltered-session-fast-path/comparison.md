# Experiment 2a: skip redundant qualification for unfiltered KPIs

## Scope

Experiment 1 was fully reverted before this change. The original calendar join is restored. Only api_kpis session_metrics changed: skip filtered_sessions when both date bounds are explicit and no hit-level or session-level attribute filters are defined. All other cases retain the original qualification join. Missing/one-sided bounds retain it because filtered_sessions and mv_session_data have different default bounds. This tests the initial unfiltered fast path of option 2; conditional aggregation for filtered requests is not implemented.

## Validation

- Explicit local build succeeded and reported only endpoints/api_kpis.pipe changed.
- All 23 existing KPI fixture tests passed, including hourly buckets, current-hour cutoff, timezone, hit/session filters, gift links and missing date_to.
- Same 26 cases and exact manifest; one warm-up plus five measurements, sequential requests, 4 GiB memory limit. Dataset metadata matches the original baseline.
- All 30 KPI requests succeeded; all successful result hashes across the entire benchmark match the original baseline.
- Overall 155/156 requests succeeded. One unchanged api_top_utm_campaigns-history request in round 2 timed out at the local 10-second limit. The runner exited 1; the failure remains recorded.
- All 156 requests have logs: 155 QueryFinish entries plus one exception log in failed-query-logs.json.
- git diff --check passed. Repository-wide application checks were not run for this isolated Tinybird SQL experiment.

## KPI medians

| Case | HTTP before → after ms | Change | CPU before → after ms | Peak before → after MiB | Rows before → after |
|---|---:|---:|---:|---:|---:|
| api_kpis-30d | 360.1 → 165.9 | -53.9% | 840.3 → 540.2 | 664.8 → 211.3 | 3893430 → 1946716 |
| api_kpis-history | 4153.5 → 871.5 | -79.0% | 23586.6 → 3407.1 | 2961.7 → 1002.4 | 19999938 → 9999970 |
| api_kpis-post-30d | 264.9 → 277.8 | +4.9% | 1339.2 → 1425.2 | 337.2 → 334.9 | 15840113 → 15840113 |
| api_kpis-source-30d | 411.5 → 402.4 | -2.2% | 1323.9 → 1383.5 | 725.9 → 736.6 | 5840144 → 5840144 |
| api_kpis-audience-30d | 370.3 → 338.6 | -8.6% | 905.6 → 888.3 | 660.7 → 663.9 | 3893431 → 3893431 |

## Deployed plan evidence

| Case | Hit reads before → after | Join nodes before → after |
|---|---:|---:|
| api_kpis-30d | 2 → 1 | 3 → 2 |
| api_kpis-history | 2 → 1 | 3 → 2 |
| api_kpis-post-30d | 4 → 4 | 6 → 6 |
| api_kpis-source-30d | 3 → 3 | 4 → 4 |
| api_kpis-audience-30d | 2 → 2 | 3 → 3 |

## Interpretation

Unfiltered full-history requests show a clear local improvement: duration -79.0%, CPU -85.6%, peak memory -66.2%, rows and bytes read approximately halved. Thirty-day unfiltered requests improve too. Filtered KPI SQL is identical to the baseline, so changes in those timings are run-to-run variation, not effects of this optimization.

The benchmark audience case explicitly supplies all generated member statuses and therefore does not use the fast path. Actual benefit depends on whether callers omit attribute filters; this experiment does not optimize requests with an explicit all-statuses filter. No speedup is claimed for source/post/audience cases.

No concurrency test or production-capacity inference was made. The candidate is deployed locally and uncommitted; both earlier experiment datasets and baseline artifacts remain intact.

See summary.md for the complete endpoint matrix, results.json for raw samples/query logs, explain/ for deployed SQL/plans, source-snapshot/ and change.diff for the exact candidate, and checksums.json for artifact integrity.
