# Experiment 3: hourly session-metric summaries

## Scope and semantic preservation

Experiment 2a was reverted. The original calendar and qualification joins remain. A new AggregatingMergeTree datasource stores count/min/max timestamp states per site, UTC hour and session. For explicit UTC date ranges, api_kpis reads those states, filters hours before merging by session, then uses the original filtered_sessions qualification (including member_status). This preserves range-clipped pageviews, duration, bounce and date attribution. Session-level source/device/UTM qualification still uses the original raw-hit aggregation.

Non-UTC or missing/one-sided dates fall back to mv_session_data. This prototype does not claim to solve arbitrary timezone/partial-hour boundaries, does not remove the default audience filter and does not change ingestion validation. Existing non-UTC tests passed through the fallback. No changes to other API endpoints.

## Validation and reproducibility

- Local build created _mv_kpi_session_hours_experiment and mv_kpi_session_hours_experiment and updated api_kpis. Build automatically populated the summary from existing data; no raw data reset or reingestion.
- An explicit count of the new table found 3,691,532 stored summary rows representing exactly 10,000,000 hits.
- All 23 existing api_kpis fixture tests passed, including audience, source/UTM, post/path/gift, timezone, hourly and missing-date cases.
- Exact original 26-case manifest, one warm-up plus five measured rounds, concurrency 1, 4 GiB limit. Benchmark-site dataset metadata matches the original baseline.
- 156/156 successful requests with matched query logs; every result hash matched the original baseline.
- git diff --check passed. No full application suite was run for the isolated Tinybird experiment.

## KPI medians

| Case | HTTP before → after ms | CPU before → after ms | Peak before → after MiB | Rows before → after | Read MiB before → after |
|---|---:|---:|---:|---:|---:|
| api_kpis-30d | 360.1 → 394.2 | 840.3 → 960.1 | 664.8 → 656.6 | 3893430 → 2667322 | 181.9 → 157.6 |
| api_kpis-history | 4153.5 → 4054.3 | 23586.6 → 21383.6 | 2961.7 → 2763.9 | 19999938 → 13691481 | 934.6 → 808.8 |
| api_kpis-post-30d | 264.9 → 314.8 | 1339.2 → 1555.2 | 337.2 → 341.4 | 15840113 → 14614005 | 1184.1 → 1159.8 |
| api_kpis-source-30d | 411.5 → 451.2 | 1323.9 → 1417.5 | 725.9 → 737.0 | 5840144 → 4614036 | 291.0 → 266.7 |
| api_kpis-audience-30d | 370.3 → 512.5 | 905.6 → 1083.9 | 660.7 → 662.1 | 3893431 → 2667323 | 211.9 → 187.6 |

## Deployed plan evidence

- api_kpis-30d: ReadFromMergeTree (_mv_kpi_session_hours_experiment), ReadFromMergeTree (_mv_hits)
- api_kpis-history: ReadFromMergeTree (_mv_kpi_session_hours_experiment), ReadFromMergeTree (_mv_hits)
- api_kpis-post-30d: ReadFromMergeTree (_mv_kpi_session_hours_experiment), ReadFromMergeTree (_mv_hits), ReadFromMergeTree (_mv_hits), ReadFromMergeTree (_mv_hits)
- api_kpis-source-30d: ReadFromMergeTree (_mv_kpi_session_hours_experiment), ReadFromMergeTree (_mv_hits), ReadFromMergeTree (_mv_hits)
- api_kpis-audience-30d: ReadFromMergeTree (_mv_kpi_session_hours_experiment), ReadFromMergeTree (_mv_hits)

## Storage and ingestion tradeoff

Datasource API reports _mv_hits at 497,313,224 bytes (~474 MiB) and the new summary at 170,556,336 bytes (~163 MiB), with 3,691,532 rows. The summary is additional storage, about 34% of the existing hit table size; raw hits remain necessary. These are the datasource API byte statistics, not per-query bytes read.

Each future hit insertion now also contributes count/min/max states to the new MV. Steady-state ingestion overhead, late-arrival performance and merge workload have NOT been benchmarked. Build/population completed in 6.1 seconds, which is not a controlled ingestion-throughput measurement. Do not claim a net production resource saving from this run.

## Conclusion

This prototype lowers full-history rows read by 31.5% and bytes read by 13.5%, but does not demonstrate a compelling latency improvement: median HTTP 4.15 → 4.05 s, CPU 23.59 → 21.38 s, peak memory 2.89 → 2.70 GiB. For the default-audience 30-day case, median HTTP increased 370 → 513 ms, CPU 906 → 1,084 ms, and peak memory stayed about 661 MiB. Several unchanged endpoints were also slower, so elapsed-time differences are confounded by local run variation.

The remaining qualification scan, session merges and large joins limit how much this isolated preaggregation can remove. Further gains would need a different query shape or coarser summaries with more careful filter/session semantics; this experiment is not evidence that all materialization approaches fail. It is not ready for shipping.

Candidate remains deployed locally and uncommitted. No Admin, TrafficAnalytics or tracker changes were made. Prior baseline/experiment files remain untouched.

## Artifacts

results.json, samples.ndjson, summary.md, manifest.json, metadata.json and explain/ contain the standard benchmark outputs. storage.json and local-settings.json record environment/storage observations. source-snapshot/ and source-hashes.json include the new materializations directory, which the original runner does not hash automatically. changes.diff includes new and modified Tinybird resources. checksums.json covers this archive.
