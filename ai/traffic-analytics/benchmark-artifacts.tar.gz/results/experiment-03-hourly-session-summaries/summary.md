# Traffic analytics baseline

Measured 5 sequential requests per case after one warm-up. CPU is summed user + system thread time; memory is query-log peak memory.

| Case | HTTP median ms | Engine ms | Rows read | Read MiB | CPU ms | Peak MiB | OK / errors |
|---|---:|---:|---:|---:|---:|---:|---:|
| api_kpis-30d | 394.17 | 377.09 | 2667322 | 157.63 | 960.12 | 656.65 | 5 / 0 |
| api_kpis-history | 4054.27 | 4025.35 | 13691481 | 808.79 | 21383.61 | 2763.87 | 5 / 0 |
| api_top_pages-30d | 674.10 | 599.15 | 11946682 | 1233.69 | 3130.61 | 598.87 | 5 / 0 |
| api_top_pages-history | 3742.34 | 3723.28 | 19999936 | 1610.02 | 22346.79 | 2810.15 | 5 / 0 |
| api_top_sources-30d | 326.61 | 271.26 | 3893428 | 200.00 | 1029.22 | 744.03 | 5 / 0 |
| api_top_sources-history | 3399.12 | 3383.01 | 19999936 | 1027.40 | 20369.84 | 2770.28 | 5 / 0 |
| api_top_locations-30d | 389.63 | 343.51 | 11946682 | 620.07 | 1319.81 | 571.81 | 5 / 0 |
| api_top_locations-history | 2701.04 | 2679.51 | 19999936 | 996.40 | 11178.13 | 2417.95 | 5 / 0 |
| api_top_devices-30d | 401.88 | 369.15 | 3893428 | 209.79 | 1154.95 | 756.80 | 5 / 0 |
| api_top_devices-history | 4240.48 | 4225.14 | 19999936 | 1077.65 | 27910.40 | 2801.23 | 5 / 0 |
| api_top_utm_sources-30d | 474.16 | 375.50 | 3893428 | 199.01 | 1143.78 | 734.34 | 5 / 0 |
| api_top_utm_sources-history | 3604.52 | 3580.09 | 19999936 | 1022.33 | 22328.87 | 2720.58 | 5 / 0 |
| api_top_utm_mediums-30d | 407.54 | 358.42 | 3893428 | 198.41 | 1092.13 | 721.70 | 5 / 0 |
| api_top_utm_mediums-history | 3542.38 | 3528.35 | 19999936 | 1019.24 | 22065.70 | 2738.79 | 5 / 0 |
| api_top_utm_campaigns-30d | 488.44 | 426.82 | 3893428 | 200.73 | 1365.41 | 720.32 | 5 / 0 |
| api_top_utm_campaigns-history | 3741.16 | 3714.54 | 19999936 | 1031.16 | 21744.47 | 2736.29 | 5 / 0 |
| api_top_utm_terms-30d | 397.71 | 345.68 | 3893428 | 196.79 | 961.98 | 711.44 | 5 / 0 |
| api_top_utm_terms-history | 3421.78 | 3383.96 | 19999936 | 1010.89 | 19794.63 | 2642.55 | 5 / 0 |
| api_top_utm_contents-30d | 339.07 | 307.13 | 3893428 | 196.79 | 821.41 | 707.97 | 5 / 0 |
| api_top_utm_contents-history | 3225.74 | 3209.61 | 19999936 | 1010.89 | 18471.95 | 2627.29 | 5 / 0 |
| api_kpis-post-30d | 314.83 | 271.26 | 14614005 | 1159.78 | 1555.17 | 341.40 | 5 / 0 |
| api_post_visitor_counts-lifetime | 151.44 | 138.42 | 9999968 | 745.84 | 1137.52 | 226.19 | 5 / 0 |
| api_kpis-source-30d | 451.24 | 437.35 | 4614036 | 266.66 | 1417.47 | 737.04 | 5 / 0 |
| api_kpis-audience-30d | 512.53 | 497.43 | 2667323 | 187.56 | 1083.86 | 662.12 | 5 / 0 |
| api_active_visitors-live | 14.29 | 3.54 | 0 | 0.00 | 4.97 | 8.05 | 5 / 0 |
| api_gift_link_visits-lifetime | 15.53 | 6.02 | 0 | 0.00 | 7.22 | 7.06 | 5 / 0 |

See metadata.json for dataset coverage and source hashes; results.json for individual requests, ranges, result hashes, and missing query-log metrics. Explain files contain expanded SQL and index/granule pruning.

Known coverage gaps are recorded in metadata.dataset. Empty-result queries are not representative of populated dimensions. Live visitor requests cannot be replayed at a frozen time.
