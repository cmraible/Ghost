# Experiment 4: combine session qualification and metrics

## Change

The api_kpis session-metrics path now groups raw hits once, computes count/min/max over all in-range hits, and qualifies sessions with countIf(combined hit predicates) > 0. Member status uses exactly the current allowed-list expansion (paid includes comped and gift); all hit predicates must match the same hit. Source/device/UTM predicates use argMin over the complete in-range session, not only matching hits. No member-status filter is removed, including the default Admin all-audiences filter.

The optimized path requires both explicit date bounds. Missing/one-sided bounds preserve the original mv_session_data plus filtered_sessions join because their date defaults differ. All timezones use the same timestamp bounds and bucket logic as before. The separate post/path/gift pageview branch remains unchanged. The original calendar join remains.

The hourly-summary query from experiment 3 is reverted. Its experimental table and MV remain installed locally but are not referenced by this candidate query; this change needs only api_kpis.pipe and does not depend on new ingestion state, Admin changes or removal of filters. No raw data was reset.

## Validation

- Explicit Tinybird Local build succeeded with only api_kpis.pipe changed.
- All 23 existing KPI fixture tests passed, covering date/hourly/current-time behavior, timezone, hit and session attribute filters, paid/gift handling and missing date_to.
- Same 26-case manifest, one warm-up plus five measured rounds, concurrency 1, 4 GiB query limit. Benchmark dataset metadata unchanged.
- 156/156 requests succeeded with corresponding query logs; all result hashes matched the original baseline.
- git diff --check passed. Full application checks were not run for the isolated SQL experiment.
- Existing tests/benchmark do not exhaust every combination of changing within-session statuses and equal-timestamp attribution ties. The gain is from a local synthetic workload, not a production concurrency measurement.

## KPI medians

| Case | HTTP before → after ms | HTTP change | CPU before → after ms | Peak before → after MiB | Rows before → after |
|---|---:|---:|---:|---:|---:|
| api_kpis-30d | 360.1 → 221.9 | -38.4% | 840.3 → 605.9 | 664.8 → 220.0 | 3893430 → 1946716 |
| api_kpis-history | 4153.5 → 916.6 | -77.9% | 23586.6 → 3513.9 | 2961.7 → 1187.0 | 19999938 → 9999970 |
| api_kpis-post-30d | 264.9 → 274.5 | +3.6% | 1339.2 → 1489.2 | 337.2 → 308.7 | 15840113 → 13893399 |
| api_kpis-source-30d | 411.5 → 118.9 | -71.1% | 1323.9 → 551.2 | 725.9 → 275.6 | 5840144 → 1946716 |
| api_kpis-audience-30d | 370.3 → 203.4 | -45.1% | 905.6 → 569.0 | 660.7 → 213.4 | 3893431 → 1946717 |

## Deployed plan evidence

| Case | Hit reads before → after | Joins before → after |
|---|---:|---:|
| api_kpis-30d | 2 → 1 | 3 → 2 |
| api_kpis-history | 2 → 1 | 3 → 2 |
| api_kpis-post-30d | 4 → 3 | 6 → 5 |
| api_kpis-source-30d | 3 → 1 | 4 → 2 |
| api_kpis-audience-30d | 2 → 1 | 3 → 2 |

## Interpretation

The default-audience 30-day KPI case is 45% faster, with CPU -37% and peak memory -68%; it retains member_status=undefined,free,paid. The source-filtered case is 71% faster, CPU -58% and peak memory -62%. Full-history unfiltered KPIs are 78% faster, CPU -85% and peak memory -60%. These gains are accompanied by structural reductions in scans and joins, not just timing differences.

The post-filtered case is essentially flat in time (+4%) with a modest memory reduction (~8%). Its separate pageview branch still reads all-history hits and repeats qualification, so this candidate does not address that cost. Unchanged endpoint timing varies between runs; small percentage differences should not be treated as causal.

The deferred member-status validation/omission proposal remains separate. This candidate can help current Admin requests without changing that contract. Before shipping, refine correctness coverage for boundary/mixed-hit cases and remove unused experimental resources from the proposed diff. No PR or production deployment was performed.

## Artifacts

Standard results/summary/manifest/metadata/explain outputs, local-settings.json, source-snapshot/, source-hashes.json, change.diff and checksums.json are preserved here, outside the repository. All earlier baseline and experiment artifacts remain untouched.
