# Traffic analytics baseline

Measured 5 sequential requests per case after one warm-up. CPU is summed user + system thread time; memory is query-log peak memory.

| Case | HTTP median ms | Engine ms | Rows read | Read MiB | CPU ms | Peak MiB | OK / errors |
|---|---:|---:|---:|---:|---:|---:|---:|
| api_kpis-30d | 221.92 | 207.34 | 1946716 | 90.97 | 605.90 | 219.97 | 5 / 0 |
| api_kpis-history | 916.62 | 898.79 | 9999970 | 467.30 | 3513.87 | 1187.00 | 5 / 0 |
| api_top_pages-30d | 341.09 | 328.98 | 11946682 | 1233.69 | 1998.54 | 593.66 | 5 / 0 |
| api_top_pages-history | 3380.69 | 3365.23 | 19999936 | 1610.02 | 20221.78 | 2786.75 | 5 / 0 |
| api_top_sources-30d | 306.48 | 295.94 | 3893428 | 200.00 | 1060.51 | 749.06 | 5 / 0 |
| api_top_sources-history | 3475.59 | 3459.06 | 19999936 | 1027.40 | 21815.62 | 2718.55 | 5 / 0 |
| api_top_locations-30d | 366.64 | 308.48 | 11946682 | 620.07 | 1288.57 | 576.91 | 5 / 0 |
| api_top_locations-history | 2681.61 | 2663.04 | 19999936 | 996.40 | 10747.52 | 2417.94 | 5 / 0 |
| api_top_devices-30d | 359.88 | 329.43 | 3893428 | 209.79 | 1049.90 | 752.57 | 5 / 0 |
| api_top_devices-history | 3911.91 | 3891.71 | 19999936 | 1077.65 | 26354.66 | 2867.44 | 5 / 0 |
| api_top_utm_sources-30d | 386.40 | 324.06 | 3893428 | 199.01 | 1126.19 | 731.58 | 5 / 0 |
| api_top_utm_sources-history | 3287.51 | 3264.32 | 19999936 | 1022.33 | 20290.66 | 2736.23 | 5 / 0 |
| api_top_utm_mediums-30d | 390.34 | 339.55 | 3893428 | 198.41 | 1135.56 | 729.22 | 5 / 0 |
| api_top_utm_mediums-history | 3289.98 | 3266.08 | 19999936 | 1019.24 | 19807.13 | 2742.95 | 5 / 0 |
| api_top_utm_campaigns-30d | 344.83 | 298.81 | 3893428 | 200.73 | 980.37 | 728.85 | 5 / 0 |
| api_top_utm_campaigns-history | 3413.21 | 3381.45 | 19999936 | 1031.16 | 20054.71 | 2730.94 | 5 / 0 |
| api_top_utm_terms-30d | 335.33 | 294.51 | 3893428 | 196.79 | 916.75 | 707.90 | 5 / 0 |
| api_top_utm_terms-history | 3033.55 | 3008.05 | 19999936 | 1010.89 | 17539.03 | 2576.96 | 5 / 0 |
| api_top_utm_contents-30d | 301.26 | 265.52 | 3893428 | 196.79 | 827.98 | 711.57 | 5 / 0 |
| api_top_utm_contents-history | 3188.65 | 3169.49 | 19999936 | 1010.89 | 18360.96 | 2622.68 | 5 / 0 |
| api_kpis-post-30d | 274.53 | 234.91 | 13893399 | 1093.12 | 1489.18 | 308.71 | 5 / 0 |
| api_post_visitor_counts-lifetime | 151.32 | 134.47 | 9999968 | 745.84 | 1080.06 | 229.37 | 5 / 0 |
| api_kpis-source-30d | 118.94 | 104.30 | 1946716 | 109.03 | 551.15 | 275.56 | 5 / 0 |
| api_kpis-audience-30d | 203.35 | 182.78 | 1946717 | 120.90 | 569.03 | 213.38 | 5 / 0 |
| api_active_visitors-live | 15.64 | 3.36 | 0 | 0.00 | 4.74 | 8.05 | 5 / 0 |
| api_gift_link_visits-lifetime | 20.98 | 5.49 | 0 | 0.00 | 6.58 | 7.06 | 5 / 0 |

See metadata.json for dataset coverage and source hashes; results.json for individual requests, ranges, result hashes, and missing query-log metrics. Explain files contain expanded SQL and index/granule pruning.

Known coverage gaps are recorded in metadata.dataset. Empty-result queries are not representative of populated dimensions. Live visitor requests cannot be replayed at a frozen time.
